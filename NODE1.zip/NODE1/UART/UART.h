/**
 * @file UART.h
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for the UART interface
 * on ATMEL ATmega162 microcontrollers.
 * @see https://ww1.microchip.com/downloads/en/DeviceDoc/Atmel-2513-8-bit-AVR-Microntroller-ATmega162_Datasheet.pdf
 */
 
#ifndef UART_H_
#define UART_H_
#include <stdint.h>

#define FOSC (uint32_t)4950000
#define BAUD (uint32_t)9600
#define UBRR (uint32_t)((FOSC/(16*BAUD) - 1))


void UART_init(uint32_t ubrr);
void UART_puts(char *data, uint8_t data_size);
void UART_putc(char data);
char UART_recieve(void);


#endif /* UART_H_ */