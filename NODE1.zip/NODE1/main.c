/**
 * @file main.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief TTK4155 term project Node 1 main file.
 * Contains a program for playing a weird, mechanical game of single player ping-pong
 * in an old, drawer like box.
 * This program controls Node 1 of 2. Node 1 handles user input, GUI and communicates with
 * Node 2, which in turn controls the actual game board and related peripherals.
 *
 * @see https://learn-eu-central-1-prod-fleet01-xythos.content.blackboardcdn.com/5def77a38a2f7/6703234?X-Blackboard-Expiration=1605549600000&X-Blackboard-Signature=kR2rPbCcma7Xc1F62autZtNHQtLNI3XFz7obPfK0UXU%3D&X-Blackboard-Client-Id=303508&response-cache-control=private%2C%20max-age%3D21600&response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27TTK4155_Embedded_and_Industrial_Computer_Systems_Term_Project_2020%25282%2529.pdf&response-content-type=application%2Fpdf&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20201116T120000Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=AKIAZH6WM4PL5M5HI5WH%2F20201116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Signature=5133e7426f7f2ae9ad6bef0c96fb875e59701a148fb2e83a3195f8f706f239c7
 */


#include <avr/io.h>
#include <avr/interrupt.h>

#include "main.h"
#ifdef EX
#include "Exercise/Exercise.h"
#endif

void Send_position(void);

volatile uint8_t running = 0;			///< @brief Game running flag.
extern volatile uint8_t ready;			///< @brief Node 2 ready flag. Definition in msg_handler.c	
extern volatile uint8_t start;			///< @brief Game start message flag. Definition in msg_handler.c
extern volatile uint8_t Goal;			///< @brief Goal scored flag. Definition in msg_handler.c
extern volatile uint8_t Heartbeat;  	///< @brief Node heartbeat @note Not implemented. Replaced by ready polling. Definition in msg_handler.c
extern volatile pos_t position;			///< @brief global position structure. Continously updated with user input. Shared between nodes.
extern volatile uint32_t ms_tick;   	///< @brief Counts every 100ms. Used for score-keeping. Definition in Timer.c
volatile uint16_t current_score = 0;	///< @brief Current score counter



/**
 * @brief Main program function
 *
 * @param none
 * @retval fail
 */ 
int main(void)
{
	GPIO_init();
	SRAM_init();
	UART_init(UBRR);
	Joystick_init();
	slider_init();
	OLED_init();
	Menu_init();
	CAN_init(MODE_NORMAL);
	
	Timer_init();
	Timer3_start();
	
	sei();	

	Send_msg(READY);
	printf("start \n");
	
    while (1) 
    {	
		//Send_position();
		Send_msg(POSITION);
		_delay_ms(100);
		
		if(!running)			//If game is not running, run the menu system
		{
 			Menu_selection();
			_delay_ms(100);
			Goal = 0;
		}
		else					//Game running
		{
			if(Goal)			//If a goal is scored, write game over, update highscores, and reset flags.
			{
				Menu_write_game_over(current_score);
				Timer1_stop();
				start = 0;
				running = 0;
				current_score = 0;
				Goal = 0;
			}
			else				//If no goal has been scored, output current score on OLED.
			{
				Menu_write_score(current_score++);
			}
		}
	}
 		
	return 1;
}


void GPIO_init(void)
{
	DDRB &= ~(1 << PB1);
	DDRB |= 1 << PB0;
	PORTB |= 1 << PB1;
	
	DDRE |= 1 << PE2;
	
	DDRE &= ~(1 << JOYSTICK_PIN);
	PORTE |= 1 << JOYSTICK_PIN;
	
	set_bit(MCUCR, ISC01);
	clear_bit(MCUCR, ISC00);
	set_bit(GICR, INT2);
	
	DDRD &= ~(1 << 2);
	
	GICR |= 1<<6;
	MCUCR |= 0x2;	
}

/*
void Send_position(void)
{
	Joystick_pos_t j_pos = Joystick_get_position();
	Slider_pos_t s_pos = Slider_get_position();
	
	CAN_MESSAGE pos_msg;
	pos_msg.ID = 'P';
	pos_msg.data[0] = Joystick_read_button();
	pos_msg.data[1] = j_pos.dir;
	pos_msg.data[2] = j_pos.x_pos;
	pos_msg.data[3] = j_pos.y_pos;
	pos_msg.data[4] = s_pos.R_pos;	
	pos_msg.data[5] = s_pos.L_pos;
	
	pos_msg.data_length = 6;
	
	CAN_send(&pos_msg);
}
*/