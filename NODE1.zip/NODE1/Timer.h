/**
 * @file TIMER.h
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for the using the timer/counter module
 * on ATMEL ATmega162 microcontrollers.
 * @see https://ww1.microchip.com/downloads/en/DeviceDoc/Atmel-2513-8-bit-AVR-Microntroller-ATmega162_Datasheet.pdf
 */

#ifndef TIMER_H_
#define TIMER_H_

#include "avr/io.h"
#include "avr/interrupt.h"
#include "stdint.h"
#include "stdio.h"
#include "stdlib.h"
void Timer_init(void);
void Timer1_start(void);
void Timer1_stop(void);
void Timer3_start(void);
void Timer3_stop(void);


#endif /* TIM_H_ */