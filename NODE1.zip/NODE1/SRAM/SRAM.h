/**
 * @file ADC.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for external, memory mapped, SRAM.
 * @see https://www.idt.com/eu/en/document/dst/7164sl-data-sheet
 * @see http://www.farnell.com/datasheets/1468098.pdf
 * @see https://ww1.microchip.com/downloads/en/DeviceDoc/Atmel-2513-8-bit-AVR-Microntroller-ATmega162_Datasheet.pdf *
 */
 
#ifndef SRAM_H_
#define SRAM_H_


#include <avr/io.h>
#include <avr/interrupt.h>


void SRAM_init(void);
uint8_t SRAM_write(uint8_t *data, uint16_t adress, uint8_t size);
uint8_t SRAM_read(uint8_t *data, uint16_t adress, uint8_t size);
void SRAM_test(void);


#endif /*SRAM_H_*/