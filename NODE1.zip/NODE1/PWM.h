/**
 * @file PWM.h
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for the using a timer in PWM mode
 * on ATMEL ATmega162 microcontrollers.
 * @see https://ww1.microchip.com/downloads/en/DeviceDoc/Atmel-2513-8-bit-AVR-Microntroller-ATmega162_Datasheet.pdf
 */
 
#ifndef PWM_H_
#define PWM_H_

void PWM_init(void);

#endif /* PWM_H_ */