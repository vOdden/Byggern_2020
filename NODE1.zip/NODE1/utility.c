/**
 * @file utility.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing miscellaneous headers, datatypes and functions
 */

#include "Utility.h"


/**
 * @brief Utility function for printing direction.
 *
 * @param  dir: Direction to print
 * @retval none
 */
void print_direction(Direction_t dir)
{
	switch(dir)
	{
		case NEUTRAL:
			printf("NEUTRAL");
		break;
		
		case UP:
			printf("UP");
		break;
		
		case DOWN:
			printf("DOWN");
		break;
		
		case LEFT:
			printf("LEFT");
		break;
		
		case RIGHT:
			printf("RIGHT");
		break;

		default:
			printf("DIR ERROR");
		break;		
	}
}