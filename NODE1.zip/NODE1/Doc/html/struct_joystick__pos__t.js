var struct_joystick__pos__t =
[
    [ "dir", "struct_joystick__pos__t.html#aacb6e39341e62ca496420f9441ad31eb", null ],
    [ "x_pos", "struct_joystick__pos__t.html#afd5b7de4eebb6b1f325bb6e5d0cbd97f", null ],
    [ "y_pos", "struct_joystick__pos__t.html#a34c402cbff3f62bc89fd892f2ff89af3", null ]
];