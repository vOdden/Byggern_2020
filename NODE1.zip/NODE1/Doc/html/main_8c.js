var main_8c =
[
    [ "GPIO_init", "main_8c.html#a75690af9e89afd801dc40b20b5c813f1", null ],
    [ "main", "main_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "Send_position", "main_8c.html#a0b202f49591af4ba074bdb6009234d37", null ],
    [ "current_score", "main_8c.html#ac1e051b9e57a3e7f3a5e96742dee5657", null ],
    [ "Goal", "main_8c.html#af4f97d6c1c7a30088dd9b8ee8c90cac4", null ],
    [ "Heartbeat", "main_8c.html#a187c8f3285d67ec158d1e001af67464f", null ],
    [ "ms_tick", "main_8c.html#a02d6250ff76e120f5af25df363b730d1", null ],
    [ "position", "main_8c.html#acfb7d2523bb3ae66cdfddcff83c1d34f", null ],
    [ "ready", "main_8c.html#a3dec6baf6b8e19f87fb59089679d3094", null ],
    [ "running", "main_8c.html#ac67984a6e5389dd80651c6a155fb9976", null ],
    [ "start", "main_8c.html#a02e361d4120ede469c0ee933cc02346d", null ]
];