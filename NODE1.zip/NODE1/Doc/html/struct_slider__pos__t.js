var struct_slider__pos__t =
[
    [ "L_button", "struct_slider__pos__t.html#a44b1f352c44f80116d35c3521dbea688", null ],
    [ "L_pos", "struct_slider__pos__t.html#a5966b4cb90aa2d9ac42d97f1d95e3df4", null ],
    [ "R_button", "struct_slider__pos__t.html#a2942b1813f75b4b79ccd76beb4218f89", null ],
    [ "R_pos", "struct_slider__pos__t.html#a23ade87c04a0a7421a260bddcc9c3f29", null ]
];