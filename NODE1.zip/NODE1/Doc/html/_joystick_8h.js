var _joystick_8h =
[
    [ "Joystick_Calibrate", "_joystick_8h.html#a24035137e4a31a8d98f2f9547baca43e", null ],
    [ "Joystick_get_direction", "_joystick_8h.html#aa01e2386df0fced3bebb915680e9503d", null ],
    [ "Joystick_get_position", "_joystick_8h.html#a9c68904d0ee8fc654c69b3073dbb20f6", null ],
    [ "Joystick_init", "_joystick_8h.html#ab4cc3ef4bbbab2c285a97697f2d66cd4", null ],
    [ "Joystick_read_button", "_joystick_8h.html#a5ab79fb7d5e45382ad083312c635ac34", null ]
];