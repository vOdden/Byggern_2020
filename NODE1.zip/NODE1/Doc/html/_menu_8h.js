var _menu_8h =
[
    [ "menu_struct", "structmenu__struct.html", "structmenu__struct" ],
    [ "menu_t", "_menu_8h.html#a97e60d7bd09a3ff2ac173f2d51d092ae", null ],
    [ "menu_option_t", "_menu_8h.html#a34b645d7f9fdd5a19cd0e64c5fd7139c", [
      [ "NONE", "_menu_8h.html#a34b645d7f9fdd5a19cd0e64c5fd7139cac157bdf0b85a40d2619cbc8bc1ae5fe2", null ],
      [ "PLAY_GAME", "_menu_8h.html#a34b645d7f9fdd5a19cd0e64c5fd7139cac258a51e9cc26e302562d2bd792430b1", null ],
      [ "GAME_OVER", "_menu_8h.html#a34b645d7f9fdd5a19cd0e64c5fd7139ca871723195985a4ae22d7e10d99bf8a00", null ],
      [ "EASY", "_menu_8h.html#a34b645d7f9fdd5a19cd0e64c5fd7139ca26d394b5caf2853dbcef5884f0f068dd", null ],
      [ "HARD", "_menu_8h.html#a34b645d7f9fdd5a19cd0e64c5fd7139ca712b8eb9268f114b4afc567f24bc536f", null ]
    ] ],
    [ "Menu_allocate_child", "_menu_8h.html#a434fda5154fe242626b2de4108869878", null ],
    [ "Menu_create_menu", "_menu_8h.html#a31989b59f508b7420d40aac5e8f87a52", null ],
    [ "Menu_edit_high_score", "_menu_8h.html#a5dae78e6172d31a8aa678db452a4198c", null ],
    [ "Menu_function_start_game", "_menu_8h.html#ab5b993cd1215144d972a9673f39e22f9", null ],
    [ "Menu_init", "_menu_8h.html#a2649e7f791a881a198b30b00922a3e5f", null ],
    [ "Menu_pgm_write_string", "_menu_8h.html#a9e1602096e447e12d60d461fa26ec13b", null ],
    [ "Menu_print_menu", "_menu_8h.html#a2e0537c1747fdff27126743a92032562", null ],
    [ "Menu_selection", "_menu_8h.html#a587feee603f03c839554ff1029c13226", null ],
    [ "Menu_wite_high_score", "_menu_8h.html#a10816a916ee261cc704f4a7c6ba00de7", null ],
    [ "Menu_write_credits", "_menu_8h.html#a57152723f6884c30a7edc49b5b6d3dc4", null ],
    [ "Menu_write_game_over", "_menu_8h.html#a4ebb9b2a16b288c2ad8047fe4e2db86d", null ],
    [ "Menu_write_score", "_menu_8h.html#adb3a9084a7590e90c277dac34b0d0828", null ],
    [ "set_difficulty_func", "_menu_8h.html#aa08e52f0c740713cac8facad9fbde8c5", null ]
];