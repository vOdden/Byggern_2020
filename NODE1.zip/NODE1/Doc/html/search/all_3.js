var searchData=
[
  ['difficulty_5fgrade_23',['difficulty_grade',['../msg__handler_8c.html#adb85228c276ac84bd0fcec362c5f6f1d',1,'difficulty_grade():&#160;Menu.c'],['../_menu_8c.html#a2268e26d2c4f21a4f435ddd560979cf5',1,'difficulty_grade():&#160;Menu.c']]],
  ['dir_24',['dir',['../structpos__t.html#aacb6e39341e62ca496420f9441ad31eb',1,'pos_t']]]
];
