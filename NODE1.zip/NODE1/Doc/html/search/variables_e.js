var searchData=
[
  ['title_483',['title',['../structmenu__struct.html#af06d911bb9e05f491ef3da520d03796c',1,'menu_struct']]],
  ['title_5fcutter_484',['title_cutter',['../_menu_8c.html#ab4567014ebcd8db9cfb294f7043e575a',1,'Menu.c']]]
];
