var searchData=
[
  ['select_5fplayer_5ffunc_410',['select_player_func',['../_menu_8c.html#aabf694ea8e92948d796e4a49549ccdef',1,'Menu.c']]],
  ['send_5fmsg_411',['Send_msg',['../msg__handler_8c.html#af6c6cc0d6eaf8e225ce84662a52d9078',1,'Send_msg(MSG_type type):&#160;msg_handler.c'],['../msg__handler_8h.html#ab375687ea4c02c5ec6e04524dd97daf8',1,'Send_msg(MSG_type):&#160;msg_handler.c']]],
  ['send_5fposition_412',['Send_position',['../main_8c.html#a0b202f49591af4ba074bdb6009234d37',1,'main.c']]],
  ['set_5fdifficulty_5ffunc_413',['set_difficulty_func',['../_menu_8c.html#aa08e52f0c740713cac8facad9fbde8c5',1,'set_difficulty_func(int8_t choice):&#160;Menu.c'],['../_menu_8h.html#aa08e52f0c740713cac8facad9fbde8c5',1,'set_difficulty_func(int8_t choice):&#160;Menu.c']]],
  ['slider_5fget_5fbutton_414',['Slider_get_button',['../_slider_8c.html#ad6fc8b73f223baaa5a1eddd21119ff6b',1,'Slider_get_button(Direction_t dir):&#160;Slider.c'],['../_slider_8h.html#ad6fc8b73f223baaa5a1eddd21119ff6b',1,'Slider_get_button(Direction_t dir):&#160;Slider.c']]],
  ['slider_5fget_5fposition_415',['Slider_get_position',['../_slider_8c.html#aef69763c01a4c520eb1084a0317e96fd',1,'Slider_get_position(void):&#160;Slider.c'],['../_slider_8h.html#aef69763c01a4c520eb1084a0317e96fd',1,'Slider_get_position(void):&#160;Slider.c']]],
  ['slider_5finit_416',['slider_init',['../_slider_8c.html#a88870ff10e8b1fc3c6751c409c6b24c3',1,'slider_init(void):&#160;Slider.c'],['../_slider_8h.html#a88870ff10e8b1fc3c6751c409c6b24c3',1,'slider_init(void):&#160;Slider.c']]],
  ['spi_5finit_417',['SPI_init',['../_s_p_i_8c.html#afd9b09f58917f0e2d14c61b956eba214',1,'SPI_init(void):&#160;SPI.c'],['../_s_p_i_8h.html#a9c9bb330f595b394b823e409ea6ca35a',1,'SPI_init():&#160;SPI.c']]],
  ['spi_5fread_418',['SPI_read',['../_s_p_i_8c.html#a73da55c9179a4f4cb9842deaebab0ba2',1,'SPI_read():&#160;SPI.c'],['../_s_p_i_8h.html#abd8eeeca17292a594a05c3225d8fe188',1,'SPI_read(void):&#160;SPI.c']]],
  ['spi_5fwrite_419',['SPI_write',['../_s_p_i_8c.html#a688f668009a7559c3eb8ca6be0f65c9c',1,'SPI_write(uint8_t cData):&#160;SPI.c'],['../_s_p_i_8h.html#a958b933ac08fd4cad89ba555bc431599',1,'SPI_write(char):&#160;SPI.h']]],
  ['sram_5finit_420',['SRAM_init',['../_s_r_a_m_8c.html#ad607bcb84cc9434b858ce5502242c54f',1,'SRAM_init(void):&#160;SRAM.c'],['../_s_r_a_m_8h.html#ad607bcb84cc9434b858ce5502242c54f',1,'SRAM_init(void):&#160;SRAM.c']]],
  ['sram_5fread_421',['SRAM_read',['../_s_r_a_m_8c.html#a9c4324f89b31b469632e3a3230f2c4ff',1,'SRAM_read(uint8_t *data, uint16_t adress, uint8_t size):&#160;SRAM.c'],['../_s_r_a_m_8h.html#a9c4324f89b31b469632e3a3230f2c4ff',1,'SRAM_read(uint8_t *data, uint16_t adress, uint8_t size):&#160;SRAM.c']]],
  ['sram_5ftest_422',['SRAM_test',['../_s_r_a_m_8c.html#a2e2934cf8f43363e11e4fd6c60db1666',1,'SRAM_test(void):&#160;SRAM.c'],['../_s_r_a_m_8h.html#a2e2934cf8f43363e11e4fd6c60db1666',1,'SRAM_test(void):&#160;SRAM.c']]],
  ['sram_5fwrite_423',['SRAM_write',['../_s_r_a_m_8c.html#aeec880c9b6c0ef63a9ca3ab90f316514',1,'SRAM_write(uint8_t *data, uint16_t adress, uint8_t size):&#160;SRAM.c'],['../_s_r_a_m_8h.html#aeec880c9b6c0ef63a9ca3ab90f316514',1,'SRAM_write(uint8_t *data, uint16_t adress, uint8_t size):&#160;SRAM.c']]]
];
