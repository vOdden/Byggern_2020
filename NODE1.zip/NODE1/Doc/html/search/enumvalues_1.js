var searchData=
[
  ['easy_496',['EASY',['../_menu_8h.html#a34b645d7f9fdd5a19cd0e64c5fd7139ca26d394b5caf2853dbcef5884f0f068dd',1,'Menu.h']]]
];
