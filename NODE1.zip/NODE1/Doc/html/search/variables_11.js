var searchData=
[
  ['x_487',['x',['../structpos__t.html#a3ed6e6c91c0b672a428f3f627dfd148b',1,'pos_t']]],
  ['x_5fpos_488',['x_pos',['../struct_joystick__pos__t.html#afd5b7de4eebb6b1f325bb6e5d0cbd97f',1,'Joystick_pos_t']]]
];
