var searchData=
[
  ['func_25',['func',['../structmenu__struct.html#a0f8f2152ba4e1dee7f4ea77408b856b0',1,'menu_struct']]]
];
