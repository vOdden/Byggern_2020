var searchData=
[
  ['adc_5fget_5fconversion_154',['ADC_get_conversion',['../_a_d_c_8c.html#a2e28f11a98e22109d9eb5f3e3418e1e4',1,'ADC_get_conversion(uint8_t *data):&#160;ADC.c'],['../_a_d_c_8h.html#a2e28f11a98e22109d9eb5f3e3418e1e4',1,'ADC_get_conversion(uint8_t *data):&#160;ADC.c']]],
  ['adc_5finit_155',['ADC_init',['../_a_d_c_8c.html#a4b4a2ddcb45df0c8497c47d4ed800e2a',1,'ADC_init(void):&#160;ADC.c'],['../_a_d_c_8h.html#a4b4a2ddcb45df0c8497c47d4ed800e2a',1,'ADC_init(void):&#160;ADC.c']]],
  ['adc_5fread_156',['ADC_read',['../_a_d_c_8c.html#ab5e427cd2e5fe71fa9a885f20606e06a',1,'ADC_read(uint8_t channel):&#160;ADC.c'],['../_a_d_c_8h.html#ab5e427cd2e5fe71fa9a885f20606e06a',1,'ADC_read(uint8_t channel):&#160;ADC.c']]]
];
