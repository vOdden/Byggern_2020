var searchData=
[
  ['node2_5fready_5fflag_72',['NODE2_READY_FLAG',['../_menu_8c.html#a7683dd775f9b0e7c4a2f7090b21e21bd',1,'Timer.c']]],
  ['number_5fof_5fchildren_73',['number_of_children',['../structmenu__struct.html#adeb20efbea78b6b0284c5cd159951824',1,'menu_struct']]]
];
