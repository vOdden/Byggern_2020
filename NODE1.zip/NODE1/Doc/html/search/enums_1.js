var searchData=
[
  ['menu_5foption_5ft_493',['menu_option_t',['../_menu_8h.html#a34b645d7f9fdd5a19cd0e64c5fd7139c',1,'Menu.h']]],
  ['msg_5ftype_494',['MSG_type',['../msg__handler_8h.html#aa01097387098cfe3153ff40404e64675',1,'msg_handler.h']]]
];
