var searchData=
[
  ['width_248',['width',['../struct_font_descr.html#a09a2a45f731b02946ff6d3cd15c1a476',1,'FontDescr']]]
];
