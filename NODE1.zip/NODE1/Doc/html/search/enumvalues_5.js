var searchData=
[
  ['neutral_501',['NEUTRAL',['../utility_8h.html#a2e9ec086ba61b35cfc2439306cdfdd70af46d14eb9d5d71afc9f6e747689fcb56',1,'utility.h']]],
  ['none_502',['NONE',['../_menu_8h.html#a34b645d7f9fdd5a19cd0e64c5fd7139cac157bdf0b85a40d2619cbc8bc1ae5fe2',1,'Menu.h']]]
];
