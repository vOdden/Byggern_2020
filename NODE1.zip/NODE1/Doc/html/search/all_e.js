var searchData=
[
  ['select_5fplayer_5ffunc_97',['select_player_func',['../_menu_8c.html#aabf694ea8e92948d796e4a49549ccdef',1,'Menu.c']]],
  ['send_5fmsg_98',['Send_msg',['../msg__handler_8c.html#af6c6cc0d6eaf8e225ce84662a52d9078',1,'msg_handler.c']]],
  ['set_5fdifficulty_5ffunc_99',['set_difficulty_func',['../_menu_8c.html#aa08e52f0c740713cac8facad9fbde8c5',1,'set_difficulty_func(int8_t choice):&#160;Menu.c'],['../_menu_8h.html#aa08e52f0c740713cac8facad9fbde8c5',1,'set_difficulty_func(int8_t choice):&#160;Menu.c']]],
  ['slider_100',['slider',['../structpos__t.html#a17a63bf5df623dfad8b2d08eb8fec666',1,'pos_t']]],
  ['slider_2ec_101',['Slider.c',['../_slider_8c.html',1,'']]],
  ['slider_2eh_102',['Slider.h',['../_slider_8h.html',1,'']]],
  ['slider_5fget_5fbutton_103',['Slider_get_button',['../_slider_8c.html#ab29d614b579c8e4f400cdcbf0a194d0c',1,'Slider_get_button(Direction_t button):&#160;Slider.c'],['../_slider_8h.html#ab29d614b579c8e4f400cdcbf0a194d0c',1,'Slider_get_button(Direction_t button):&#160;Slider.c']]],
  ['slider_5fget_5fposition_104',['Slider_get_position',['../_slider_8c.html#aef69763c01a4c520eb1084a0317e96fd',1,'Slider_get_position(void):&#160;Slider.c'],['../_slider_8h.html#aef69763c01a4c520eb1084a0317e96fd',1,'Slider_get_position(void):&#160;Slider.c']]],
  ['slider_5finit_105',['slider_init',['../_slider_8c.html#a88870ff10e8b1fc3c6751c409c6b24c3',1,'slider_init(void):&#160;Slider.c'],['../_slider_8h.html#a88870ff10e8b1fc3c6751c409c6b24c3',1,'slider_init(void):&#160;Slider.c']]],
  ['slider_5fpos_5ft_106',['Slider_pos_t',['../struct_slider__pos__t.html',1,'']]],
  ['spi_2ec_107',['SPI.c',['../_s_p_i_8c.html',1,'']]],
  ['spi_5finit_108',['SPI_init',['../_s_p_i_8c.html#afd9b09f58917f0e2d14c61b956eba214',1,'SPI.c']]],
  ['spi_5fread_109',['SPI_read',['../_s_p_i_8c.html#a8659f8495774df2bbf5f10f47224bb7e',1,'SPI.c']]],
  ['spi_5fwrite_110',['SPI_write',['../_s_p_i_8c.html#a688f668009a7559c3eb8ca6be0f65c9c',1,'SPI.c']]],
  ['start_111',['start',['../msg__handler_8c.html#a02e361d4120ede469c0ee933cc02346d',1,'start():&#160;msg_handler.c'],['../main_8c.html#a02e361d4120ede469c0ee933cc02346d',1,'start():&#160;msg_handler.c'],['../_menu_8c.html#a02e361d4120ede469c0ee933cc02346d',1,'start():&#160;msg_handler.c']]]
];
