var searchData=
[
  ['y_489',['y',['../structpos__t.html#aa8648aa0bb6df77525620af6fcb214cf',1,'pos_t']]],
  ['y_5fpos_490',['y_pos',['../struct_joystick__pos__t.html#a34c402cbff3f62bc89fd892f2ff89af3',1,'Joystick_pos_t']]]
];
