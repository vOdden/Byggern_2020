var searchData=
[
  ['parent_235',['parent',['../structmenu__struct.html#a3fe7a7d3f630baf8d275d7534e354383',1,'menu_struct']]],
  ['position_236',['position',['../msg__handler_8c.html#acfb7d2523bb3ae66cdfddcff83c1d34f',1,'position():&#160;msg_handler.c'],['../main_8c.html#acfb7d2523bb3ae66cdfddcff83c1d34f',1,'position():&#160;msg_handler.c']]]
];
