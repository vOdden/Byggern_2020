var _a_d_c_8h =
[
    [ "ADC_get_conversion", "_a_d_c_8h.html#a2e28f11a98e22109d9eb5f3e3418e1e4", null ],
    [ "ADC_init", "_a_d_c_8h.html#a4b4a2ddcb45df0c8497c47d4ed800e2a", null ],
    [ "ADC_read", "_a_d_c_8h.html#ab5e427cd2e5fe71fa9a885f20606e06a", null ]
];