var struct_c_a_n___m_e_s_s_a_g_e =
[
    [ "data", "struct_c_a_n___m_e_s_s_a_g_e.html#afb87d045bbf32b236fc425efe02bdc7b", null ],
    [ "data_length", "struct_c_a_n___m_e_s_s_a_g_e.html#ad97c802f66f41e937c3f8b33337b8c6d", null ],
    [ "ID", "struct_c_a_n___m_e_s_s_a_g_e.html#a9bb81603329def43dbb55e1ae69996d9", null ]
];