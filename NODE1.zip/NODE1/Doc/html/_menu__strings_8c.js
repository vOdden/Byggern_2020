var _menu__strings_8c =
[
    [ "credit_name", "_menu__strings_8c.html#aa8e72f121e7763555691a5b37d189301", null ],
    [ "MENU_CREDITS_STRING", "_menu__strings_8c.html#a4923c47afd6db440e5c34d9bbc76ecb5", null ],
    [ "MENU_GAME_STRINGS", "_menu__strings_8c.html#aa55f1760b94f32e9ecbcf862d40c6d12", null ],
    [ "MENU_START_STRINGS", "_menu__strings_8c.html#accedf570e17338a1beee22f95e63519c", null ],
    [ "MENU_TITLE_STRINGS", "_menu__strings_8c.html#a6e5c75bac1633d206e6272122744b64c", null ]
];