var structpos__t =
[
    [ "button", "structpos__t.html#a8273db344fd3a2b068599f6cadba12f4", null ],
    [ "dir", "structpos__t.html#aacb6e39341e62ca496420f9441ad31eb", null ],
    [ "slider", "structpos__t.html#a17a63bf5df623dfad8b2d08eb8fec666", null ],
    [ "x", "structpos__t.html#a3ed6e6c91c0b672a428f3f627dfd148b", null ],
    [ "y", "structpos__t.html#aa8648aa0bb6df77525620af6fcb214cf", null ]
];