var _slider_8h =
[
    [ "Slider_get_button", "_slider_8h.html#ab29d614b579c8e4f400cdcbf0a194d0c", null ],
    [ "Slider_get_position", "_slider_8h.html#aef69763c01a4c520eb1084a0317e96fd", null ],
    [ "slider_init", "_slider_8h.html#a88870ff10e8b1fc3c6751c409c6b24c3", null ]
];