var annotated_dup =
[
    [ "CAN_MESSAGE", "struct_c_a_n___m_e_s_s_a_g_e.html", "struct_c_a_n___m_e_s_s_a_g_e" ],
    [ "Joystick_pos_t", "struct_joystick__pos__t.html", "struct_joystick__pos__t" ],
    [ "menu_struct", "structmenu__struct.html", "structmenu__struct" ],
    [ "pos_t", "structpos__t.html", "structpos__t" ],
    [ "Slider_pos_t", "struct_slider__pos__t.html", "struct_slider__pos__t" ]
];