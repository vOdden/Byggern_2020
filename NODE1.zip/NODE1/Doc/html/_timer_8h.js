var _timer_8h =
[
    [ "Timer1_start", "_timer_8h.html#a749935b8a16799c2d16b38735ca48799", null ],
    [ "Timer1_stop", "_timer_8h.html#a032e4851ffa26196f7281ae4e21d85fe", null ],
    [ "Timer3_start", "_timer_8h.html#a5915eba0afa1dd5f8d90a2d36486a990", null ],
    [ "Timer3_stop", "_timer_8h.html#adf681ceb4e6a7519f30bce6f81634d82", null ],
    [ "Timer_init", "_timer_8h.html#ace12508d33b354c0194b6f72cfc3bf12", null ]
];