var _s_p_i_8h =
[
    [ "SPI_init", "_s_p_i_8h.html#a9c9bb330f595b394b823e409ea6ca35a", null ],
    [ "SPI_read", "_s_p_i_8h.html#abd8eeeca17292a594a05c3225d8fe188", null ],
    [ "SPI_write", "_s_p_i_8h.html#a958b933ac08fd4cad89ba555bc431599", null ]
];