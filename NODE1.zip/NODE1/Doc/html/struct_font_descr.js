var struct_font_descr =
[
    [ "addr", "struct_font_descr.html#ae5bd6c22dbf0f6b5b0ae0233f8eb3704", null ],
    [ "height", "struct_font_descr.html#adcf201a8aabf55cb352ec05331242594", null ],
    [ "start_offset", "struct_font_descr.html#a65522dc141095acb796a910f8e05075d", null ],
    [ "width", "struct_font_descr.html#a09a2a45f731b02946ff6d3cd15c1a476", null ]
];