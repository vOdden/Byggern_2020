var structmenu__struct =
[
    [ "child", "structmenu__struct.html#a2fe895957073da02d071ba068822e644", null ],
    [ "func", "structmenu__struct.html#a0f8f2152ba4e1dee7f4ea77408b856b0", null ],
    [ "number_of_children", "structmenu__struct.html#adeb20efbea78b6b0284c5cd159951824", null ],
    [ "parent", "structmenu__struct.html#a3fe7a7d3f630baf8d275d7534e354383", null ],
    [ "title", "structmenu__struct.html#af06d911bb9e05f491ef3da520d03796c", null ]
];