var _menu_8c =
[
    [ "Menu_allocate_child", "_menu_8c.html#a434fda5154fe242626b2de4108869878", null ],
    [ "Menu_create_menu", "_menu_8c.html#a31989b59f508b7420d40aac5e8f87a52", null ],
    [ "Menu_edit_high_score", "_menu_8c.html#a5dae78e6172d31a8aa678db452a4198c", null ],
    [ "Menu_function_start_game", "_menu_8c.html#ab5b993cd1215144d972a9673f39e22f9", null ],
    [ "Menu_init", "_menu_8c.html#a2649e7f791a881a198b30b00922a3e5f", null ],
    [ "Menu_pgm_write_string", "_menu_8c.html#a9e1602096e447e12d60d461fa26ec13b", null ],
    [ "Menu_print_menu", "_menu_8c.html#a2e0537c1747fdff27126743a92032562", null ],
    [ "Menu_selection", "_menu_8c.html#a587feee603f03c839554ff1029c13226", null ],
    [ "Menu_wite_high_score", "_menu_8c.html#a10816a916ee261cc704f4a7c6ba00de7", null ],
    [ "Menu_write_credits", "_menu_8c.html#ad1b2e64074a044fe8e6cae9aeb96d903", null ],
    [ "Menu_write_game_over", "_menu_8c.html#a4ebb9b2a16b288c2ad8047fe4e2db86d", null ],
    [ "Menu_write_score", "_menu_8c.html#adb3a9084a7590e90c277dac34b0d0828", null ],
    [ "select_player_func", "_menu_8c.html#aabf694ea8e92948d796e4a49549ccdef", null ],
    [ "set_difficulty_func", "_menu_8c.html#aa08e52f0c740713cac8facad9fbde8c5", null ],
    [ "current_menu", "_menu_8c.html#adfd70aa5a7b9b7747b512af3a82a2846", null ],
    [ "current_menu_size", "_menu_8c.html#a748b96d9e200c795ef8bdd24628d7c61", null ],
    [ "difficulty_grade", "_menu_8c.html#a2268e26d2c4f21a4f435ddd560979cf5", null ],
    [ "NODE2_READY_FLAG", "_menu_8c.html#a7683dd775f9b0e7c4a2f7090b21e21bd", null ],
    [ "ready", "_menu_8c.html#a3dec6baf6b8e19f87fb59089679d3094", null ],
    [ "running", "_menu_8c.html#ac67984a6e5389dd80651c6a155fb9976", null ],
    [ "start", "_menu_8c.html#a02e361d4120ede469c0ee933cc02346d", null ]
];