var _menu__strings_8h =
[
    [ "credit_name", "_menu__strings_8h.html#a6edea29350145bce04b75bc86b02128a", null ],
    [ "MENU_CREDITS_STRING", "_menu__strings_8h.html#ac4c00166f01f55cbdd306098d0ddbddc", null ],
    [ "MENU_GAME_STRINGS", "_menu__strings_8h.html#ac427319e099eb0fbdb9e26bb9cd83865", null ],
    [ "MENU_START_STRINGS", "_menu__strings_8h.html#a7623831969dc42f7b9cb730641293343", null ],
    [ "MENU_TITLE_STRINGS", "_menu__strings_8h.html#af39c8a23bdb3d06e30446724628a6547", null ]
];