var _s_p_i_8c =
[
    [ "SPI_init", "_s_p_i_8c.html#afd9b09f58917f0e2d14c61b956eba214", null ],
    [ "SPI_read", "_s_p_i_8c.html#a8659f8495774df2bbf5f10f47224bb7e", null ],
    [ "SPI_write", "_s_p_i_8c.html#a688f668009a7559c3eb8ca6be0f65c9c", null ]
];