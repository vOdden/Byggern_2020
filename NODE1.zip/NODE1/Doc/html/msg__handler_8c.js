var msg__handler_8c =
[
    [ "msg_handler", "msg__handler_8c.html#a76199aaf7cc14cbbe12679d191f2a0e0", null ],
    [ "Send_msg", "msg__handler_8c.html#af6c6cc0d6eaf8e225ce84662a52d9078", null ],
    [ "difficulty_grade", "msg__handler_8c.html#adb85228c276ac84bd0fcec362c5f6f1d", null ],
    [ "Goal", "msg__handler_8c.html#af4f97d6c1c7a30088dd9b8ee8c90cac4", null ],
    [ "Heartbeat", "msg__handler_8c.html#a187c8f3285d67ec158d1e001af67464f", null ],
    [ "position", "msg__handler_8c.html#acfb7d2523bb3ae66cdfddcff83c1d34f", null ],
    [ "ready", "msg__handler_8c.html#a3dec6baf6b8e19f87fb59089679d3094", null ],
    [ "start", "msg__handler_8c.html#a02e361d4120ede469c0ee933cc02346d", null ]
];