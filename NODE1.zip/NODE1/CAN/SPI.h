/**
 * @file SPI.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for the SPI interface
 * on ATMEL ATmega162 microcontrollers.
 * @see https://ww1.microchip.com/downloads/en/DeviceDoc/Atmel-2513-8-bit-AVR-Microntroller-ATmega162_Datasheet.pdf
 */
 
#ifndef SPI_H_
#define SPI_H_

void SPI_init(void);
void SPI_write(char);
uint8_t SPI_read(void);

#endif /* SPI_H_ */