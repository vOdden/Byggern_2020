/**
 * @file CAN_driver.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing low level drivers for the MCP2515 CAN bus controller.
 * @see https://ww1.microchip.com/downloads/en/DeviceDoc/MCP2515-Stand-Alone-CAN-Controller-with-SPI-20001801J.pdf
 */
 
#include "CAN_driver.h"
#include "../bit_macros.h"

#include <avr/io.h>
#define F_CPU 4915200UL
#include <util/delay.h>
#include "stdio.h"


/**
 * @brief Activates the CAN-controller.
 * Pulls MCP2515 slave select low.
 *
 * @param  none
 * @retval none
 */ 
void MCP_activate(void)
{
	clear_bit(PORTB, PB4);
}


/**
 * @brief Deactivates the CAN-controller.
 * Pulls MCP2515 slave select high.
 *
 * @param  none
 * @retval none
 */ 
void MCP_deactivate(void)
{
	/* Deactivate Chip Select */
	set_bit(PORTB, PB4);
}


/**
 * @brief Configures the mode of the CAN-controller.
 * See possible modes in MCP2515.h
 *
 * @param  mode: mode
 * @retval none
 */ 
void MCP_set_mode(uint8_t mode)
{
	MCP_write(MCP_CANCTRL, mode);
}


/**
 * @brief Initialization function for the MCP2515 CAN-controller
 * Configures relevant peripherals and goes through initialization-
 * sequence
 *
 * @param  mode: MCP2515 mode
 * @retval uint8_t: fail/succeed
 */ 
uint8_t MCP_init(uint8_t mode)
{	
	uint8_t mcp_status;
	SPI_init();										//Initialize SPI
	MCP_reset();									//Reset CAN-controller
	
	mcp_status = MCP_read(MCP_CANSTAT);				//Read CAN-controller status register 
	uint8_t current_mode = (mcp_status & MODE_MASK);//Check MCP2515 mode after reset 
	
	if(current_mode != MODE_CONFIG)					//If not in config mode, return error
	{
		printf("MCP2515 is NOT in Configuration mode after reset! Its config bits are %x\n", mcp_status);
		return 1;
	}
	
	MCP_set_mode(mode);								//Set CAN-controller in desired mode
	
	mcp_status = MCP_read(MCP_CANSTAT);				//Read status
	current_mode = (mcp_status & MODE_MASK);		//Check mode
	
	if(current_mode != mode)						//If controller is not in desired mode, return error
	{	
		printf("MCP2515 is NOT in correct mode after reset! Its config bits are %x\n", mcp_status);
		printf("\n!\n");
		return 1;
	}	
	
	return 0;
}


/**
 * @brief Reset the CAN-controller.
 * Writes reset command over SPI to MCP2515.
 *
 * @param none
 * @retval none
 */ 
void MCP_reset(void)
{
	MCP_activate();
	SPI_write(MCP_RESET);
	MCP_deactivate();
	_delay_ms(10);
}


/**
 * @brief Read a byte from the CAN-controller.
 * Read data from an adress in the MCP2515.
 *
 * @param adress:  read adress
 * @retval uint8_t: read value
 */ 
uint8_t MCP_read(uint8_t address)
{
	MCP_activate();
	
	uint8_t data;
	
	SPI_write(MCP_READ);	//Send read command to MCP2515
	SPI_write(address);		//Send read adress
	data = SPI_read();		//Read data from adress
	
	MCP_deactivate();
	
	return data;
}


/**
 * @brief Write a byte to the CAN-controller.
 * Write data to an adress in the MCP2515.
 *
 * @param adress: Write adress
 * @param data: Write data
 * @retval none
 */
void MCP_write(uint8_t address, uint8_t data) 
{
	MCP_activate();
	
	SPI_write(MCP_WRITE);	//Send write command to MCP2515
	SPI_write(address);		//Send write adress
	SPI_write(data);		//Write data to adress
	
	MCP_deactivate();
}


/**
 * @brief Request to send output buffer data on CAN buss.
 * Request to send data from an output buffer in the MCP2515
 * out on the CAN buss
 *valid arguments: MCP_RTS_TX0, MCP_RTS_TX1, MCP_RTS_TX2, MCP_RTS_ALL
 *
 * @param buffer: buffer to be output on buss
 * @retval none
 */
void MCP_request_to_send(uint8_t buffer) 
{
	MCP_activate();
	
	SPI_write(buffer);
	
	MCP_deactivate();
}


/**
 * @brief Modify arbitrary bits in the CAN-controller.
 * Write bit modify command to the MCP2515. Writes the defined bits
 * to a selected value.
 * 
 * @param adress: adress of register to be modified
 * @param mask: bitmask to mask out bits that are not to be modified
 * @param data: the new bit data
 * @retval none
 */
void MCP_bit_modify(uint8_t adress, uint8_t mask, uint8_t data) 
{
	MCP_activate();
	
	SPI_write(MCP_BITMOD);
	SPI_write(adress);
	SPI_write(mask);
	SPI_write(data);
	
	MCP_deactivate();
}


/**
 * @brief Read CAN-controller status register
 * 
 * @param none
 * @retval uint8_t: Contents of MCP2515 status register
 */
uint8_t MCP_read_status(void) 
{
	MCP_activate();
	
	SPI_write(MCP_READ_STATUS);
	uint8_t status = SPI_read();
	
	MCP_deactivate();
	
	return status;
}