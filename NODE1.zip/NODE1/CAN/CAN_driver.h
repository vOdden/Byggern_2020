/**
 * @file CAN_driver.h
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing low level drivers for the MCP2515 CAN bus controller.
 * @see https://ww1.microchip.com/downloads/en/DeviceDoc/MCP2515-Stand-Alone-CAN-Controller-with-SPI-20001801J.pdf
 */
 
#ifndef CAN_DRIVER_H_
#define CAN_DRIVER_H_

#include <stdint.h>
#include "SPI.h"
#include "MCP2515.h"

uint8_t MCP_init(uint8_t mode);
void MCP_set_mode(uint8_t mode);
void MCP_reset(void);
uint8_t MCP_read(uint8_t address);
void MCP_write(uint8_t address, uint8_t data);
void MCP_request_to_send(uint8_t buffer);
void MCP_bit_modify(uint8_t adress, uint8_t mask, uint8_t data);
uint8_t MCP_read_status(void);

#endif /* CAN_DRIVER_H_ */