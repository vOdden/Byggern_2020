/**
 * @file msg_handler.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing CAN bus message handling.
 */

#ifndef MSG_HANDLER_H_
#define MSG_HANDLER_H_

#include "CAN.h"
#include "../utility.h"
#include <stdint.h>

/**
 * @brief Consolidated position data structure.
 * Contains the necessary user inputs for playing the game
 */ 
typedef struct {
	Direction_t dir;	///< Joystick direction
	int8_t x;			///< Joystick X-value
	int8_t y;			///< Joystick Y-value
	uint8_t button;		///< Joystick button press flag
	uint8_t slider;		///< Right slider value
}pos_t;

/**
 * @brief Message type enum.
 */ 
typedef enum
{
	START,
	READY,
	STOP,
	GOAL,
	POSITION,
}MSG_type;

void Send_msg(MSG_type);
void msg_handler(CAN_MESSAGE* can_msg);

#endif /* MSG_HANDLER_H_ */