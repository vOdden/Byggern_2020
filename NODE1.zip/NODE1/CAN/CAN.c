/**
 * @file CAN.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing top level drivers for MCU based CAN bus communication.
 * Recieved messages is put into a rolling, FIFO register of CAN messages.
 * Messages are also handled at recieve time, to update relevant global datastructures.
 * See msg_handler.h
 */
 

#include "CAN.h"
#include "msg_handler.h"

CAN_MESSAGE CAN_INPUT_BUFFER[8];		///< @brief Rolling CAN input message buffer 
uint8_t CAN_BUFFER_CTR = 0;				///< @brief CAN input message buffer counter
uint8_t CAN_first_rx = 0;				///< @brief First valid CAN_input message flag
uint8_t valid_messages = 0;				///< @brief Number of valid CAN messages in input buffer

//static volatile int flag = 0;			

/**
 * @brief CAN ISR
 * ISR for MCP2515 events. Trigged by falling edge on /INT pin.
 * Handles and sorts incomming messages.
 *
 * @param  none
 * @retval none
 */ 
ISR(INT0_vect)
{
	//flag = 1;
	
	if( MCP_read(MCP_CANINTF) & MCP_RX0IF)					//If message recieved in input buffer 0
	{
		CAN_receive(0, &(CAN_INPUT_BUFFER[CAN_BUFFER_CTR]));	//Recieve message into rolling buffer
		valid_messages++;										//Increment number of valid messages
		MCP_bit_modify(MCP_CANINTF, MCP_RX0IF, 0);				//Clear RX0 interrupt
		//printf("Message received in CAN buffer 0 \n");
		//printf("Message: %s \n",CAN_INPUT_BUFFER[CAN_BUFFER_CTR].data);
		if(++CAN_BUFFER_CTR >= 8)								//If the next input buffer is 8 => roll over to start
		{
			CAN_BUFFER_CTR = 0;
		}
	}
	if( MCP_read(MCP_CANINTF) & MCP_RX1IF)						//If message recieved in input buffer 1
	{
		CAN_receive(1, &(CAN_INPUT_BUFFER[CAN_BUFFER_CTR]));	//Recieve message into rolling buffer
		valid_messages++;										//Increment number of valid messages
		MCP_bit_modify(MCP_CANINTF , MCP_RX1IF, 0);		//Clear RX0 interrupt
		//printf("Message received in CAN buffer 1 \n");
		if(++CAN_BUFFER_CTR >= 8)								//If the next input buffer is 8 => roll over to start
		{
			CAN_BUFFER_CTR = 0;
		}
	}
	MCP_write(MCP_CANINTF, 0);
}


/**
 * @brief Read data from input buffer
 *
 * @param  RX_packet: pointer to data destination
 * @retval int8_t: fail/success
 */ 
int8_t CAN_read(CAN_MESSAGE* RX_packet)
{
	if(valid_messages > 0)
	{
		valid_messages--;
		*RX_packet = CAN_INPUT_BUFFER[CAN_first_rx];
		
		if(++CAN_first_rx >= 8 )
		{
			CAN_first_rx = 0;
		}
		return 0;
	}
	else
	{
		return -1;
	}
}

/*
int CAN_interrupt()
{
	if(flag)
	{
		flag = 0;
		return 1;
	}
	return 0;
}
*/

/*
int CAN_RXcmplt(void)
{
	if(flag == 0)
	{
		return 0;
	}
	uint8_t interrupt_flag = MCP_read(MCP_CANINTF);
	interrupt_flag |= interrupt_flag & (MCP_RX0IF | MCP_RX1IF); //RX0 complete
//	vector[1] = interrupt_flag & MCP_RX1IF; //RX1 complete
	return interrupt_flag;
}
*/

/**
 * @brief Initialization function for the top layer CAN interface.
 * Configures relevant peripherals and goes through initialization-
 * sequence
 *
 * @param  mode: MCP2515 mode
 * @retval none
 */ 
void CAN_init(uint8_t mode)
{
	for(uint8_t i = 0; i < 8; i++)	//Initialize all CAN input buffer IDs to zero
	{
		CAN_INPUT_BUFFER[i].ID = 0;
	}

	MCP_init(MODE_CONFIG);				//Initialize CAN-controller
	MCP_write(MCP_CANINTE, MCP_RX_INT);	//Enable RX complete interrupts
	
	//printf("CANINTE: %x \n", mcp_2515_read(MCP_CANINTE));
	
	//Set up baud rate
	uint8_t _BRP = 7; 					//Baud rate prescaler. TQ = 2 (BRP+1)/Fosc. 7 gir BAUD = 1MHz @ 16MHz(?) TQ = 1us
	uint8_t _SJW = (0x80); 				// Synchronization jump width(?)
	uint8_t CNF_CONF = _SJW | _BRP;
	
	MCP_write(MCP_CNF1, CNF_CONF);	//Configure CAN buss baud rate
	
	//length of propagation segment = TQ x PRSEG. 	
	//length of PHG1 == TQ x PHSEG1
	//BTLMODE == 1 => PH2 settes av PHSEG2. Sett denne
	
	uint8_t _PRSEG = (1 << 0);
	uint8_t _SAM = (0 << 6);
	uint8_t _BTLMODE = (1 << 7);
	uint8_t _PHSEG1 = (6 << 3);
	
	CNF_CONF = _PRSEG | _SAM | _BTLMODE | _PHSEG1;
	MCP_write(MCP_CNF2, CNF_CONF);

	uint8_t RXBnCTRL_CONF = 3 << 5; //Turn mask/filter off
//	 RXBnCTRL_CONF |= 1 << 3; //remote transfer request(?)

	MCP_write(MCP_RXB0CTRL,RXBnCTRL_CONF);
	MCP_write(MCP_RXB1CTRL,RXBnCTRL_CONF);

	//length of PHG2 == TQ x PHSEG2
	//SOF?????????????
	uint8_t _PHSEG2 = (6 << 0);
	uint8_t _WAKFIL = (0 << 6);
	uint8_t _SOF = (0 << 7);
		
	CNF_CONF = _PHSEG2 | _WAKFIL | _SOF;
	MCP_write(MCP_CNF3, CNF_CONF);
	
	MCP_bit_modify(MCP_CANCTRL, ~(1<<4) ,1 << 4); //Set one shot mode
	
	MCP_set_mode(mode);
	
	//disable global interrupt
	cli();
	//interrupt on falling edge. PD2
	set_bit(MCUCR, ISC01);
	clear_bit(MCUCR, ISC00);
	//Interrupt enable PD2.
	set_bit(GICR, INT0);
	
	sei();
	
}


/**
 * @brief Sends a CAN message out on the buss
 *
 * @param  TX_packet: Pointer to the message to be sendt.
 * @retval none
 */ 
void CAN_send(CAN_MESSAGE* TX_packet)
{
	static uint8_t buffer_number = 0;		//Variable for choosing output buffer
	
	//Check if the current buffer_number is available to send.
	//Rotate through buffers until one is available.
	while(!CAN_TXcomplete(buffer_number))
	{
		buffer_number++;
		if(buffer_number > 2)
		{
			buffer_number = 0;
		}		
	}
	
	//Report data length to CAN-controller
	MCP_write(MCP_TXB0DLC + (buffer_number << 4), TX_packet->data_length);
	
	//Write data to transmit buffer
	for (int i = 0; i < TX_packet->data_length; i++)
	{
		MCP_write(MCP_TXB0Dm + i + (buffer_number << 4), TX_packet->data[i]);
	}
	
	//ID: 0xabcd == 16 bit.		xxxx x|xxx xxxx xxxx
	//CAN ID == 11bit, SIDH		
		
	//Canbuss ID is 11 bit, contained unaligned across two registers.
	//Do some bit-shuffling to properly align TX_packet.ID
	MCP_write(MCP_TXB0SIDH + (buffer_number << 4), (TX_packet->ID >> 3));
	MCP_write(MCP_TXB0SIDL + (buffer_number << 4), (TX_packet->ID << 5));
		
	//request to send 	
	MCP_request_to_send(MCP_RTS_TX0 + buffer_number);
}


/**
 * @brief Read a recieved CAN message from the CAN-controller
 *
 * @param RX_buffer: MCP2515 RX buffer to be processed
 * @param RX_packet: Pointer to message storage
 * @retval none
 */ 
void CAN_receive(int RX_buffer, CAN_MESSAGE* RX_packet)
{
	//Read high and low message ID-bytes
	//Canbuss ID is 11 bit, contained unaligned across two registers.
	//Do some bit-shuffling to properly align TX_packet.ID
	uint16_t RX_IDh = MCP_read(MCP_RXB0SIDH + (RX_buffer << 4)) << 3;
	uint16_t RX_IDL = MCP_read(MCP_RXB0SIDL + (RX_buffer << 4));
	RX_IDL = RX_IDL >> 5;
	RX_packet->ID = RX_IDh | RX_IDL; 
	
	//uint8_t RX_data_length = MCP_read(MCP_RXB0DLC + (RX_buffer << 4));

	//Get packet data length
	RX_packet->data_length = MCP_read(MCP_RXB0DLC + (RX_buffer << 4)) & 0x0F;
	
	//Get data
	for(int i = 0; i < RX_packet->data_length; i++)
	{
		RX_packet->data[i] = MCP_read(MCP_RXB0DM + i + (RX_buffer << 4));
	}
	
	//Handle the recieved message
	msg_handler(RX_packet);
}


/**
 * @brief Report CAN Transmit complete
 * Checks if an CAN output buffer have been successfully been written
 * to the buss.
 *
 * @param buffer_number: ouput buffer
 * @retval int8_t: fail/success
 */ 
int8_t CAN_TXcomplete(uint8_t buffer_number)
{
	uint8_t transmit_flag = MCP_read(MCP_CANINTF);
	uint8_t interrupts = transmit_flag &( MCP_TX0IF + (buffer_number << 1));

	if(interrupts == (MCP_TX0IF + (buffer_number << 1)))
	{
		return 0;
	}
	return 1;
}


/**
 * @brief Reports CAN errors and interrupt flags
 *
 * @param  none
 * @retval uint8_t: error message
 */ 
uint8_t CAN_error(void)
{
	uint8_t error = MCP_read(MCP_EFLG); 	//Read error flag

	MCP_bit_modify(MCP_EFLG, error, 0);	//Reset error flag register
	
	if(error != 0)								//Print out errors
	{
		printf("CAN-ERROR \n");
		
		if(error & (1 << 0))
		{
			printf("EWARN \n");
		}		
		if(error & (1 << 1))
		{
			printf("RXWAR \n");
		}		
		if(error & (1 << 2))
		{
			printf("TXWAR \n");
		}		
		if(error & (1 << 3))
		{
			printf("RXEP \n");
		}		
		if(error & (1 << 4))
		{
			printf("TXEP \n");
		}		
		if(error & (1 << 5))//
		{
			printf("TXBO \n");
		}		
		if(error & (1 << 6))
		{
			printf("RX0OVR \n");
		}		
		if(error & (1 << 7))
		{
			printf("RX0OVR \n");
		}
	}

	if(MCP_read(MCP_CANINTF))			//Read MCP2515 interrupt flags
	{
			printf("interrupt flag: %d \n", MCP_read(MCP_CANINTF)); //Report interrupt
	}
	
	return error;
}


/*
CAN_MESSAGE CAN_handler(void)
{
	uint8_t RX_cmplt = CAN_RXcmplt();
	CAN_MESSAGE RX_packet;
	
	if(RX_cmplt & MCP_RX0IF)
	{
		CAN_receive(0, &RX_packet);
		mcp_2515_bit_modify(MCP_CANINTF, 0, 0);	
	}
	else if(RX_cmplt & MCP_RX1IF)
	{
		CAN_receive(1, &RX_packet);
		mcp_2515_bit_modify(MCP_CANINTF , 1, 0);
	}
	return RX_packet;
}
*/