/**
 * @file SPI.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for the SPI interface
 * on ATMEL ATmega162 microcontrollers.
 * @see https://ww1.microchip.com/downloads/en/DeviceDoc/Atmel-2513-8-bit-AVR-Microntroller-ATmega162_Datasheet.pdf
 */
 
#include <avr/io.h>
#include "../bit_macros.h"

/**
 * @brief Initialization function for the ATmega162 SPI peripheral.
 * Sets up GPIO and calls relevent functions to make SPI communication possible.
 *
 * @param  none
 * @retval none
 */ 
void SPI_init(void)
{	
	// Set SS, MOSI and SCK as output. MISO is input by default.
	DDRB |= (1<<PB4)|(1<<PB5)|(1<<PB7);
	// Enable SPI, Master mode, set clock rate fck/16
	SPCR |= (1<<SPE)|(1<<MSTR)|(1<<SPR0);
	
	/* Set SS-pin high */
	set_bit(PORTB, PB4);	
}

/**
 * @brief Writes a single byte on SPI. 
 * Slave-select arbitration must be handled by caller
 *
 * @param  cData: data byte
 * @retval none
 */
void SPI_write(uint8_t cData) 
{
		
	/* Start transmission */
	SPDR = cData;
	
	/* Wait for transmission complete */
	loop_until_bit_is_set(SPSR, SPIF);
}


/**
 * @brief Reads a single byte on SPI. 
 * Slave-select arbitration must be handled by caller
 *
 * @param  none
 * @retval uint8_t: SPI reading
 */
uint8_t SPI_read(void) 
{
	/* Start shifting registers by putting a char in the register */
	SPDR = 0x00;
	 
	/* Wait for receive complete */ 
	loop_until_bit_is_set(SPSR,SPIF);
	
	return SPDR;
}