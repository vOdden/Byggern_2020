/**
 * @file msg_handler.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing CAN bus message handling.
 */
 
#include <stdio.h>
#include "../utility.h"
#include "msg_handler.h"
#include "CAN.h"
#include "../Analog/Joystick.h"
#include "../Analog/Slider.h"

volatile uint8_t ready		= 0;	///< @brief Node 2 ready flag
volatile uint8_t start		= 0;	///< @brief Game start message flag
volatile uint8_t Goal		= 0;	///< @brief Goal scored flag
volatile uint8_t Heartbeat	= 0;    ///< @brief Node heartbeat @note Not implemented. Replaced by ready polling
volatile pos_t position;			///< @brief global position structure. Continously updated with user input. Shared between nodes.

extern int8_t difficulty_grade;		///< @brief game difficulty flag. @note not implemented

/**
 * @brief CAN buss message handler.
 * Uppdates global flags and data structures based on CAN.ID
 *
 * @param  can_msg: CAN message to process
 * @retval none
 */ 
void msg_handler(CAN_MESSAGE* can_msg)
{	
	switch(can_msg->ID)
	{
		case 'P':
			position.button		= can_msg->data[0];  //uint8_t data[]
			position.dir		= can_msg->data[1];
			position.x			= can_msg->data[2];
			position.y			= can_msg->data[3];
			position.slider		= can_msg->data[4];
		break;
		
		case 'S':
			ready = can_msg->data[0];
			start = can_msg->data[1];
		break;
	
		case 'M':
			Goal = can_msg->data[0];
		break;
		
		case 'H':
			Heartbeat = can_msg->data[0];
		break;
#ifdef EX		
		case '5':
			printf("EX5 recieved \n");
			printf("Data: %s \n", can_msg->data);
		break;
		
		case '6':
			printf("EX6 recieved \n");
			int8_t i = can_msg->data[0];
			if(i > 127)
			{
				i *= -1;
			}
			printf("Joystick data: %d \n", i);
		break;
		
		case '7':
			printf("EX7 recieved \n");
			int8_t n = can_msg->data[0];
			if(n > 127)
			{
				n *= -1;
			}
 			Servo_set_position(n , 0);
		break;
#endif		
	}
}


/**
 * @brief CAN buss standard output package constructor.
 * Assembles and sends standard CAN packages.
 *
 * @param  type: Type of message to send
 * @retval none
 */ 
void Send_msg(MSG_type type)
{	
	CAN_MESSAGE msg;
	
	switch(type)
	{
		case START:
			msg.ID = 'S';
			msg.data_length = 2;
			msg.data[0] = 0xFF; //READY
			msg.data[1] = 0xFF; //START
		break;

		case READY:
			msg.ID = 'S';
			msg.data_length = 2;
			msg.data[0] = 0xFF;
			msg.data[1] = 0x00;
		break;
		
		case STOP:	
			msg.ID = 'S';
			msg. data_length = 2;
			msg.data[0] = 0xFF;
			msg.data[1] = 0x00;
		break;
		
		case GOAL:
			msg.ID = 'M';
			msg. data_length = 1;
			msg.data[0] = 1;
		break;
		
		case POSITION:
		{
			Joystick_pos_t j_pos = Joystick_get_position();;
			Slider_pos_t s_pos = Slider_get_position();
							
			msg.ID = 'P';
			msg.data[0] = Joystick_read_button();
			msg.data[1] = j_pos.dir;
			msg.data[2] = j_pos.x_pos;
			msg.data[3] = j_pos.y_pos;
			msg.data[4] = s_pos.R_pos;
			msg.data[5] = s_pos.L_pos;
			msg.data_length = 6;
		}
		break;
		
		default:
			return;		
	}
	
	CAN_send(&msg);
}
