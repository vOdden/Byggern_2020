/**
 * @file PWM.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for the using a timer in PWM mode
 * on ATMEL ATmega162 microcontrollers.
 * @see https://ww1.microchip.com/downloads/en/DeviceDoc/Atmel-2513-8-bit-AVR-Microntroller-ATmega162_Datasheet.pdf
 */
 
#include "PWM.h"
#include "avr/io.h"


/**
 * @brief Initialization function for ATmega162 timer0 peripheral in PWM mode.
 *
 * @param  none
 * @retval none
 */
void PWM_init(void)
{
	TCCR0 = 1 << 6 | 1 << 3;
	TCCR0 |= 3 << COM00;
	TCCR0 |= 1;
	
	TCNT0 = 20;
	OCR0 = 10;
}