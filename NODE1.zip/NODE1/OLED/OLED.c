/**
 * @file OLED.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for interfacing with the OLED screen
 * on the NIMRON P1000 USB Multifunction board.
 * @see http://nimron.net/P1000/
 */
 
#include <avr/pgmspace.h>
#include <stdarg.h>
#include <stdio.h>

#include "OLED.h"
#include "fonts/fontdescr.h"
#include "string.h"
#include "fonts.h"

/**
 * @brief Initialization function for P1000 OLED.
 * Goes through an intialization sequence.
 * @param  none
 * @retval none
 */ 
void OLED_init(void)
{
	OLED_write_cmd(0xae); //	display off
	OLED_write_cmd(0xa1); //	segment remap
	OLED_write_cmd(0xda); //	common pads hardware: alternative
	OLED_write_cmd(0x12);
	OLED_write_cmd(0xc8); //	common output scan direction:com63-com()
	OLED_write_cmd(0xa8); //	multiplex ration mode:63
	OLED_write_cmd(0x3f); //
	OLED_write_cmd(0xd5); //	display divide ratio/osc. freq. mode
	OLED_write_cmd(0x80);
	OLED_write_cmd(0x81); //	contrast control
	OLED_write_cmd(0x50);
	OLED_write_cmd(0xd9); //	set pre-charge period
	OLED_write_cmd(0x21);
	OLED_write_cmd(0x20); //	Set Memory Addressing Mode
	OLED_write_cmd(0x02);
	OLED_write_cmd(0xdb); //	VCOM deselect level mode
	OLED_write_cmd(0x30);
	OLED_write_cmd(0xad); //	master configuration
	OLED_write_cmd(0x00);
	OLED_write_cmd(0xa4); //	out follows RAM content
	OLED_write_cmd(0xa6); //	set normal display
	OLED_write_cmd(0xaf); //	display on
	
	OLED_clear();
	OLED_home();
};


/**
 * @brief Writes a command to the OLED
 *
 * @param cmd: OLED command
 * @retval none
 */
void OLED_write_cmd(char cmd)
{
	*OLED_CMD_ADDRESS = cmd;
}


/**
 * @brief Clears the OLED.
 * Returns to 0,0
 *
 * @param none
 * @retval none
 */
void OLED_clear(void){
    
	for(uint8_t i = 0; i < OLED_LINES; i++)
	{
        OLED_clear_line(i);
    }
	OLED_home();
}


/**
 * @brief Clears a line one the OLED.
 *
 * @param line: line to clear
 * @retval none
 */
void OLED_clear_line(uint8_t line)
{
    OLED_goto(line, 0);
    
	for(int col = 0; col < OLED_WIDTH; col++)
	{
        OLED_WRITE_ADDRESS[col] = 0x00;
    }
	OLED_goto(line, 0);
}


/**
 * @brief Goes to first line, first column
 *
 * @param none
 * @retval none
 */
void OLED_home(void)
{
	OLED_goto(0,0);
}


/**
 * @brief Goes to a specific line and column on the OLED
 *
 * @param line: line
 * @param column: column
 * @retval none
 */
void OLED_goto(uint8_t line, uint8_t column)
{
	OLED_goto_line(line);
	OLED_goto_column(column);
}


/**
 * @brief Goes to a specific line on the OLED
 *
 * @param line: line
 * @retval none
 */
void OLED_goto_line(uint8_t line)
{
	if(line < OLED_LINES)
	{
		OLED_write_cmd(0xB0 + line);	// Page start address
		//current_line = line;
	}
}


/**
 * @brief Goes to a specific column on the OLED
 *
 * @param column: column
 * @retval none
 */
void OLED_goto_column(uint8_t column)
{
	if(column < OLED_WIDTH)
	{
		OLED_write_cmd(0x00 + (column % 16));			// Set lower column start address
		OLED_write_cmd(0x10 + (column / 16));			// Set higher column start address
	}
}


/**
 * @brief Writes a character to the OLED
 *
 * @param c: character
 * @retval none
 */
void OLED_write_char(char c)
{
	{
        for (uint8_t i = 0; i < 8; i++)
		{
			OLED_WRITE_ADDRESS[i] = pgm_read_byte(&font8[c - 32][i]); //fontx er peker til aktuell font
        }
    }
}


/**
 * @brief Writes an inverted character to the OLED
 *
 * @param c: character
 * @retval none
 */
void OLED_INV_write_char(char c)
{
        for (uint8_t i = 0; i < 8; i++)
		{
			OLED_WRITE_ADDRESS[i] = ~pgm_read_byte(&font8[c - 32][i]); //fontx er peker til aktuell font
        }
}


/**
 * @brief Writes a string to the OLED
 *
 * @param s: string
 * @retval none
 */
void OLED_write_string(char *s)
{
	for(int col = sizeof(s); col < 127; col ++)
	{
		*OLED_WRITE_ADDRESS = 0x00;
	}
	OLED_goto_column(0);
	while(*s)
	{
		OLED_write_char(*s++);
	}

}


/**
 * @brief Writes an inverted string to the OLED
 *
 * @param s: string
 * @retval none
 */
void OLED_INV_write_string(char *s)
{
	for(int col = sizeof(s); col < 127; col ++)
	{
		*OLED_WRITE_ADDRESS = 0xFF;
	}
	OLED_goto_column(0);
	while(*s)
	{
		OLED_INV_write_char(*s++);
	}
}






