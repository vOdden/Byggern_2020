/**
 * @file OLED.h
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for interfacing with the OLED screen
 * on the NIMRON P1000 USB Multifunction board.
 * @see http://nimron.net/P1000/
 */
 
#ifndef OLED_H_
#define OLED_H_

#include "fonts.h"

#define OLED_HEIGHT             64
#define OLED_WIDTH              128
#define OLED_LINES              (OLED_HEIGHT/8)

#define OLED_CMD_ADDRESS   ((volatile uint8_t *) 0x1200)
#define OLED_WRITE_ADDRESS ((volatile uint8_t *) 0x1300)

void OLED_init(void);
void OLED_write_cmd(char cmd);
void OLED_clear(void);
void OLED_clear_line(uint8_t line);
void OLED_home(void);
void OLED_goto(uint8_t line, uint8_t column);
void OLED_goto_line(uint8_t line);
void OLED_goto_column(uint8_t column);
//void OLED_font_select(FontDescr fd);
void OLED_write_char(char c);
void OLED_write_string(char *s);
void oled_printf(const char* fmt, ...);
void oled_printf_P(const char* fmt, ...);

void OLED_INV_write_char(char c);
void OLED_INV_write_string(char *s);

#endif /*OLED_H_*/


