

#ifndef EXERCISE_H_
#define EXERCISE_H_

void Exercise1(void);
void Exercise2(void);
void Exercise3(void);
void Exercise4(void);
void Exercise5(void);
void Exercise6(void);
void Exercise7(void);
void Exercise8(void);

#endif /* EXERCISE_H_ */