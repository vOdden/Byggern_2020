/**
 * @file Slider.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for interfacing with the capacitive sliders
 * on the NIMRON P1000 USB Multifunction board.
 * @see http://nimron.net/P1000/
 */
 
#include "Slider.h"
#include "ADC.h"

/**
 * @brief Initialization function for the external Joystick.
 * Sets up relevant peripherals to start recieving input from the Sliders
 * on the USB multi-function board
 *
 * @param  none
 * @retval none
 */ 
void slider_init(void)
{
    ADC_init();
}    


/**
 * @brief Gets the current position of the left and right Sliders.
 * Reads the ADC and delivers a Slider_pos_t struct with the slider values
 *
 * @param  none
 * @retval Slider positions
 */ 
Slider_pos_t Slider_get_position(void)
{
	Slider_pos_t position;
	
	uint8_t ADC_data[4]; 
	ADC_get_conversion(ADC_data);			//Read ADC-channels to ADC_data[]
		
	position.L_pos = ADC_data[ADC_SLIDER_L];
	position.R_pos = ADC_data[ADC_SLIDER_R];
		
	return position;	
}


/**
 * @brief Reads the left or right slider button.
 * Returns the current logical value of the button set by
 *
 * @param  button: Button to be read (LEFT/RIGHT)
 * @retval int8_t: Button status
 */ 
int8_t Slider_get_button(Direction_t button)
{
	switch(button)
	{
		case RIGHT:
			return read_pin(PORTD,4);
		break;
		
		case LEFT:
			return read_pin(PORTD,5);
		break;
		
		default:
			return 0;
		break;
	}
}
