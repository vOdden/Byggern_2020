/**
 * @file Joystick.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for interfacing with the Joystick on the 
 * NIMRON P1000 USB Multifunction board.
 * @see http://nimron.net/P1000/
 */

#include "Joystick.h"
#include "ADC.h"
#include "avr/io.h"
#include "avr/interrupt.h"
#include "stdlib.h"
#include "../bit_macros.h"
#include "math.h"
#include "../IO_map.h"

#define DIRECTION_THRESHOLD     80			 ///< @brief Analog direction threshold value
#define NEUTRAL_THRESHOLD   	50 			 ///< @brief Analog neutral direction threshold value

static uint8_t center_x = 0;				 ///< @brief Storage for joystick calibration value. X-axis.
static uint8_t center_y = 0;				 ///< @brief Storage for joystick calibration value. Y-axis.

static volatile uint8_t Joystick_button = 0; ///< @brief Global value for detecting interrupt trigger from Joystick button press.


/**
 * @brief Interrupt routine for Interrupt trigger 2.
 * Tied to Joystick button press. PE0
 *
 * @param  none
 * @retval none
 */ 
ISR(INT2_vect)
{
	Joystick_button = 1; //Set Joystick_button flag
	//printf("Trigger \n");
}	


/**
 * @brief Initialization function for the external Joystick.
 * Sets up relevant peripherals to start recieving input from the Joystick
 * on the USB multi-function board
 *
 * @param  none
 * @retval none
 */ 
void Joystick_init(void)
{
    ADC_init();						//Initialize ADC
    Joystick_Calibrate();			//Get Joystick offset values

	//Configure the Joystick button 
	DDRE &= ~(1 << JOYSTICK_PIN);	//Set PE0 as input
	PORTE |= 1 << JOYSTICK_PIN;		//Configure PE0 with pull up
	
	cli();							//Disable global interrupts
	
	//Configure INT2 for falling edge interrupt on PE0.
	set_bit(MCUCR, ISC01);
	clear_bit(MCUCR, ISC00);

	set_bit(GICR, INT2);			//Enable INT2/PE0 interrupts. 
	
	sei();							//Enable global interrupts
}


/**
 * @brief Updates Joystick calibration offset values.
 * Reads ADC and updates Joystick offset.
 * Joystick must be in center position for this reading to be correct.
 *
 * @param  none
 * @retval none
 */ 
void Joystick_Calibrate(void)
{
	uint8_t ADC_data[4];
	ADC_get_conversion(ADC_data);			//Read ADC-channels to ADC_data[]
	
    center_x = ADC_data[ADC_JOYSTICK_X];	//Update X-offset
    center_y = ADC_data[ADC_JOYSTICK_Y];	//Update Y-offset
}

/**
 * @brief Gets the current position of the Joystick.
 * Reads the ADC and delivers a Joystick_pos_t struct with
 * X- and Y-coordinates, as well as the current direction of
 * the Joystick. 
 *
 * @param  none
 * @retval Joystick_pos_t: Joystick position
 */ 
Joystick_pos_t  Joystick_get_position(void)
{	
/**TODO:
	* Rydde i variabler. Er mye un�dvendig mellomlagring her.
	* Den delen med direction kan godt flyttes til egen funksjon
	*/
	uint8_t ADC_data[4];
	ADC_get_conversion(ADC_data);					//Read ADC-channels to ADC_data[]
	uint8_t x_pos16 = (ADC_data[ADC_JOYSTICK_X]);
    uint8_t y_pos16 = (ADC_data[ADC_JOYSTICK_Y]);

	Joystick_pos_t pos;								//Position data structure. This is the eventual return value.
	
	static Direction_t previous_dir = NEUTRAL;		//Static direction datastructure for retaining memory of previous direction.

	pos.x_pos = x_pos16 - 128;						//Convert X-axis value to signed int8_t, with center as zero. 
	pos.y_pos = y_pos16 - 128;						//Convert Y-axis value to signed int8_t, with center as zero.
	
	//Get the absolute value of X- and Y-axis
	uint8_t x_pos_abs = abs(pos.x_pos);				
	uint8_t y_pos_abs = abs(pos.y_pos);	
	
	//Checks for direction. 
	//Detects the axis with the highest value, to decide if the direction is
	//Horizontal or vertical.
	//Checks if the read value is above or below the defined direction thresholds.
	//If the Joystick is in the "undefined region between DIRECTION_THRESHOLD and NEUTRAL_THRESHOLD
	//then the previous direction is returned
	if(x_pos_abs > y_pos_abs) 				//Check if the X- or Y-axis is dominating. If X > Y => Horizontal
	{
		if(x_pos_abs > DIRECTION_THRESHOLD)	//If the X-axis is above the threshold, update direction
		{
			if(pos.x_pos > 0)
			{
				previous_dir = RIGHT;
			}
			else
			{
				previous_dir = LEFT;
			}
		}
		else if(x_pos_abs < NEUTRAL_THRESHOLD)
		{
			previous_dir = NEUTRAL;
		}
	}
	else 									//Y > X => Vertical
	{
		if(y_pos_abs > DIRECTION_THRESHOLD)	//If the Y-axis is above the threshold, update direction
		{
			if(pos.y_pos > 0)
			{
				previous_dir = UP; //
			}
			else
			{
				previous_dir = DOWN;
			}
		}
		else if(y_pos_abs < NEUTRAL_THRESHOLD)
		{
			previous_dir = NEUTRAL;
		}

	}
	
    pos.dir = previous_dir; //Update the current position.

	return pos;		//return
}

/**
 * @brief Gets the current direction of the Joystick.
 * Reads the ADC and delivers a Direction_t enum with
 * the current direction. 
 *
 * @param  none
 * @retval Direction_t: Joystick direction
 */ 
Direction_t Joystick_get_direction(void)
{
    static Direction_t previous_dir = NEUTRAL;
    
    Joystick_pos_t pos = Joystick_get_position();
            
	uint8_t x_pos_abs = abs(pos.x_pos);
	uint8_t y_pos_abs = abs(pos.y_pos);
	
	if(x_pos_abs > y_pos_abs)
	{
		if(x_pos_abs > DIRECTION_THRESHOLD)
		{
			if(pos.x_pos > 0)
			{
				previous_dir = RIGHT;
			}
			else
			{
				previous_dir = LEFT;
			}
		}
		else if(x_pos_abs < NEUTRAL_THRESHOLD)
		{
			previous_dir = NEUTRAL;
		}
	}
	else
	{
		if(y_pos_abs > DIRECTION_THRESHOLD)
		{
			if(pos.y_pos > 0)
			{
				previous_dir = UP;
			}
			else
			{
				previous_dir = DOWN;
			}
		}
		else if(y_pos_abs < NEUTRAL_THRESHOLD)
		{
			previous_dir = NEUTRAL;
		}

	}	
	return previous_dir;
}


/**
 * @brief Checks if the joystick button has been pressed.
 * Returns and resets the Joystick_button global variable.
 *
 * @param  none
 * @retval int8_t: Joystick button status
 */ 
volatile int8_t Joystick_read_button(void)
{
	volatile int8_t retval = Joystick_button;
	Joystick_button = 0;
    return retval;
}

