/**
 * @file Joystick.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for interfacing with the Joystick on the 
 * NIMRON P1000 USB Multifunction board.
 * @see http://nimron.net/P1000/
 */
 
#ifndef Joystick_H_
#define Joystick_H_

#include <stdint.h>
#include "../utility.h"

void Joystick_init(void);
void Joystick_Calibrate(void);
Joystick_pos_t Joystick_get_position(void);
Direction_t Joystick_get_direction(void);
volatile int8_t Joystick_read_button(void);

#endif /* Joystick_H_ */