/**
 * @file ADC.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for external, memory mapped, ADC.
 * The ADC used is MAX156
 * @see https://datasheets.maximintegrated.com/en/ds/MAX155-MAX156.pdf
 *
 */
 
#include <avr/io.h>

#include "ADC.h"
#include "../utility.h"
#include "../PWM.h"

#define F_CPU 4915200UL
#include <util/delay.h>

/**
 * @brief Initialization function for the external, memory mapped, ADC.
 * Function start a PWM signal to be used as ADC clock.

 *
 * @param  none
 * @retval none
 */ 
void ADC_init(void)
{
	PWM_init(); //Start ADC clock
}


/**
 * @brief Delivers a single ADC channel conversion.
 * All channels are read, but only the selected channel is returned.
 * 
 * @param  channel: channel to be read (ADC_CHANNEL_n)
 * @retval uint8_t: channel reading (8-bits
 */ 
uint8_t ADC_read(uint8_t channel)
{
	uint8_t data[4];
	ADC_get_conversion(data);

	return data[channel];
}


/**
 * @brief Reads all (4) ADC-channels in blocking mode. 
 * If ADC_init() have not been called correctly, this function will enter an infinite loop.
 * 
 * @param  data: Array[4] where the ADC readings will be stored.
 * @retval none
 */ 
void ADC_get_conversion(uint8_t* data)
{
	//start write-sequence of ADC. Toggle WR to start conversion
	volatile uint8_t* ext_ADC = (uint8_t *) 0x1400;
	*ext_ADC = 0;	//Start conversion by reading the memory adress
	
	while(!read_pin(PINB, PB1))
	{
	}

	for(uint8_t i = 0; i < 4; i++)
	{
		data[i] = ext_ADC[0];
	}
}
