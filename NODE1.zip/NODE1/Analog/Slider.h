/**
 * @file Slider.h
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for interfacing with the capacitive sliders
 * on the NIMRON P1000 USB Multifunction board.
 * @see http://nimron.net/P1000/
 */
 
#ifndef Slider_H_
#define Slider_H_

#include <stdint.h>
#include "../utility.h"
#include <avr/io.h>

void slider_init(void);
Slider_pos_t Slider_get_position(void);
int8_t Slider_get_button(Direction_t button);

#endif /* Slider_H_*/