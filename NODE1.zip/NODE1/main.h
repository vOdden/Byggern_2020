/**
 * @file main.h
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief TTK4155 term project Node 1 main file.
 * Contains a program for playing a weird, mechanical game of single player ping-pong
 * in an old, drawer like box.
 * This program controls Node 1 of 2. Node 1 handles user input, GUI and communicates with
 * Node 2, which in turn controls the actual game board and related peripherals.
 *
 * @see https://learn-eu-central-1-prod-fleet01-xythos.content.blackboardcdn.com/5def77a38a2f7/6703234?X-Blackboard-Expiration=1605549600000&X-Blackboard-Signature=kR2rPbCcma7Xc1F62autZtNHQtLNI3XFz7obPfK0UXU%3D&X-Blackboard-Client-Id=303508&response-cache-control=private%2C%20max-age%3D21600&response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27TTK4155_Embedded_and_Industrial_Computer_Systems_Term_Project_2020%25282%2529.pdf&response-content-type=application%2Fpdf&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20201116T120000Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=AKIAZH6WM4PL5M5HI5WH%2F20201116%2Feu-central-1%2Fs3%2Faws4_request&X-Amz-Signature=5133e7426f7f2ae9ad6bef0c96fb875e59701a148fb2e83a3195f8f706f239c7
 */


#ifndef MAIN_H_
#define MAIN_H_

//#define EX

#include "string.h"

#include "Analog/ADC.h"
#include "Analog/Joystick.h"
#include "Analog/Slider.h"
#include "Analog/ADC.h"
#include "Analog/ADC.h"
#include "CAN/CAN.h"
#include "Menu/Menu.h"
#include "OLED/OLED.h"
#include "SRAM/SRAM.h"
#include "PWM.h"
#include "utility.h"
#include "UART/UART.h"
#include "CAN/msg_handler.h"
#include "Timer.h"

void GPIO_init(void);


#endif /* MAIN_H_ */