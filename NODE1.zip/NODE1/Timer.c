/**
 * @file TIMER.h
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing drivers for the using the timer/counter module
 * on ATMEL ATmega162 microcontrollers.
 * @see https://ww1.microchip.com/downloads/en/DeviceDoc/Atmel-2513-8-bit-AVR-Microntroller-ATmega162_Datasheet.pdf
 */

#include "Timer.h"

volatile uint32_t ms_tick = 0;  			///< @brief Counts every 100ms. Used for score-keeping-
volatile uint8_t NODE2_READY_FLAG = 0;		///< @brief Node 2 ready flag. Definition in msg_handler.c
extern volatile uint8_t ready;				///< @brief Node 2 ready flag. Definition in msg_handler.c 


/**
 * @brief Initialization function for ATmega162 timer1 and timer3 peripheral.
 *
 * @param  none
 * @retval none
 */
void Timer_init(void) //timer 1
{
	//Configure TC1
	//Up counter, Interrupt on timer overflow, periode = 100ms
	TCCR1A = 0x00;
	TCCR1B = (1 << CS10) | (1 << CS12); //Prescaler == 1024 => clk = 4.8kHz => t = 208us.
	TIMSK |= 1 << TOIE1;
	TCNT1 = 65536 - 480;
	
	//Configure TC3
	//Up counter, Interrupt on timer overflow, periode = 1000ms
	TCCR3A = 0x00;
	TCCR3B = (1 << CS30) | (1 << CS32); //Prescaler == 1024 => clk = 4.8kHz => t = 208us.
	ETIMSK |= 1 << TOIE3;
	TCNT3 = 65536 - 4800; //every second
	
	sei();
}


/**
 * @brief Start function for TC1
 *
 * @param  none
 * @retval none
 */
void Timer1_start(void) //timer 1
{
	ms_tick = 0;
	TCCR1B = (1 << CS10) | (1 << CS12); //Prescaler == 1024 => clk = 4.8kHz => t = 208us. Vil ha 100ms => 480 tick
}


/**
 * @brief Stop function for TC1
 *
 * @param  none
 * @retval none
 */
void Timer1_stop(void) //timer 3
{
	TCCR1B &= ~(1 << CS10) | (1 << CS12); //Prescaler == 1024 => clk = 4.8kHz => t = 208us. Vil ha 100ms => 480 tick
}


/**
 * @brief Start function for TC3
 *
 * @param  none
 * @retval none
 */
void Timer3_start(void) //timer 3
{
	TCCR3B = (1 << CS30) | (1 << CS32); //Prescaler == 1024 => clk = 4.8kHz => t = 208us. Vil ha 100ms => 480 tick
}


/**
 * @brief Stop function for TC3
 *
 * @param  none
 * @retval none
 */
void Timer3_stop(void) //timer 3
{
	TCCR3B &= ~(1 << CS30) | (1 << CS32); //Prescaler == 1024 => clk = 4.8kHz => t = 208us. Vil ha 100ms => 480 tick
}


/**
 * @brief TC1 overflow ISR.
 * Triggers and reloads every 100ms.
 * Increments ms_tick, used as a score counter.
 *
 * @param  none
 * @retval none
 */
ISR(TIMER1_OVF_vect)
{
		ms_tick++;
		TCNT1 = 65536 - 480;
}


/**
 * @brief TC3 overflow ISR.
 * Triggers and reloads every 1000ms.
 * Updates NODE2_READY_FLAG based on ping(ready) from node 2
 *
 * @param  none
 * @retval none
 */
ISR(TIMER3_OVF_vect)
{
	if(ready)
	{
		ready = 0;
		NODE2_READY_FLAG = 1;
	}
	else
	{
		NODE2_READY_FLAG = 0;
	}
	
	//printf("READY IRQ \n");
	
	TCNT3 = 65536 - 4800;
}

