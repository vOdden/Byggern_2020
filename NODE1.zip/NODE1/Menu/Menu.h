/**
 * @file Menu.h
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing functions for a menu system for the
 * OLED screen on the NIMRON P1000 USB Multifunction board
 * The menus are implemented as a doubly linked list with multiple children.
 *
 * @see http://nimron.net/P1000/
 */

#ifndef MENU_H_
#define MENU_H_

#include "../utility.h"

#define SCREEN_WIDTH 16

typedef struct menu_struct menu_t;
/**
 * @brief Menu linked list data structure
 */ 
typedef struct menu_struct
{
	/*const unsigned?*/char *title; ///@brief Pointer to title in progmem. 
	struct menu_struct* parent;		///@brief Pointer to parent. Is NULL if no parent exists.
	struct menu_struct* child[8];	///@brief Pointer to children.
	uint8_t number_of_children;		///@brief Counter to number of children.
	void (*func)(int8_t);			///@brief pointer to function to be called by the menu.
} menu_t;


/**
 * @brief Menu type enumerator
 */ 
typedef enum
{
	NONE,
	PLAY_GAME,
	GAME_OVER,
	EASY,
	HARD
} menu_option_t;


menu_t* Menu_create_menu(char* name, void (*func)(int8_t));
int8_t Menu_allocate_child(menu_t *parent, menu_t *child);
menu_t *Menu_init(void);
void Menu_print_menu(menu_t *menu, int8_t menu_ptr);
void Menu_pgm_write_string(const unsigned char *p_s, uint8_t line, uint8_t col);
void Menu_edit_high_score(uint16_t new_score, uint8_t player);
void Menu_write_game_over(uint16_t score);
void Menu_selection(void);
void Menu_write_score(uint16_t score);

//Sub-menu functions
void Menu_wite_high_score(int8_t choice);
void Menu_wite_high_score(int8_t choice);
void Menu_function_start_game(int8_t choice);
void Menu_write_credits(int8_t);
void set_difficulty_func(int8_t choice);

#endif /* MENU_H_ */