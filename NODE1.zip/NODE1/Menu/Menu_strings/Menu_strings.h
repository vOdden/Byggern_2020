/**
 * @file Menu_strings.h
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File writing constant strings used in
 * the menu system to progmem.
 */
 
#ifndef MENU_STRINGS_H_
#define MENU_STRINGS_H_

#include "avr/pgmspace.h"

const unsigned char credit_name[4][16];
const unsigned char MENU_TITLE_STRINGS[13][16];
const unsigned char MENU_START_STRINGS[8][16];
const unsigned char MENU_GAME_STRINGS[4][16];
const unsigned char MENU_CREDITS_STRING[4][16];

#define	Highscore_title_place	credit_name[0]
#define Highscore_name1_place	credit_name[1]
#define Highscore_name2_place	credit_name[2]
#define Highscore_name3_place	credit_name[3]

#define MAIN_MENU_STRING MENU_TITLE_STRINGS[0]
#define START_GAME_STRING MENU_TITLE_STRINGS[1]
#define SET_DIFFICULTY_STRING MENU_TITLE_STRINGS[2]
#define HIGH_SCORE_STRING MENU_TITLE_STRINGS[3]
#define CALIBRATE_STRING MENU_TITLE_STRINGS[4]
#define CREDITS_STRING MENU_TITLE_STRINGS[5]
#define NORMAL_STRING MENU_TITLE_STRINGS[6]
#define HARD_STRING MENU_TITLE_STRINGS[7]
#define PLAYER1_STRING MENU_TITLE_STRINGS[8]
#define PLAYER2_STRING MENU_TITLE_STRINGS[9]
#define PLAYER3_STRING MENU_TITLE_STRINGS[10]

#endif /* MENU_STRINGS_H_ */