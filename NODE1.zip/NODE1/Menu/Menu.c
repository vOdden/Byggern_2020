/**
 * @file Menu.c
 * @author TTK4155 2020 Group 28
 * @date 17 nov 2020
 * @brief File containing functions for a menu system for the
 * OLED screen on the NIMRON P1000 USB Multifunction board
 * The menus are implemented as a doubly linked list with multiple children.
 *
 * @see http://nimron.net/P1000/
 */
 
#include "../OLED/OLED.h"
#include "Menu.h"
#include "../Analog/Joystick.h"
#include "stdlib.h"
#include "string.h"
#include "../CAN/CAN.h"
#include "stdio.h"
#include "../Timer.h"
#include <string.h>
#include <stdio.h>
#include "../SRAM/SRAM.h"
#include "Menu_strings/Menu_strings.h"

extern volatile uint8_t ready;					///< @brief Node 2 ready flag. Definition in msg_handler.c	
extern volatile uint8_t start;					///< @brief Game start message flag. Definition in msg_handler.c
extern volatile uint8_t running; 				///< @brief Game running flag. Definition in main.c
extern volatile uint8_t NODE2_READY_FLAG;		///< @brief Node 2 ready ping flag. Definition in Timer.c

static uint16_t highscores[3] = {0, 0, 0};		///< @brief highscores
static int8_t current_player = 1;				///< @brief current player flag
int8_t volatile difficulty_grade = 0; 			///< @brief game difficulty flag. @note not implemented

//volatile int current_line = 2;
volatile int current_menu_size;
//volatile int score = 0;

menu_t *current_menu;							///< @brief Pointer to the current menu structure

//int cutter = 0;
//int title_cutter = 0;
//int display_line_offset = 0;


/**
 * @brief Creates a new menu.
 * Builds and allocates memory to a new menu data structure.
 * The new menu is childless and without parents :(
 *
 * @param name: Title of the menu
 * @param func: Function pointer to map to button press
 * @retval menu_t*: pointer to the created menu
 */ 
menu_t* Menu_create_menu(char* name, void (*func)(int8_t)) 
{
	menu_t* menu = malloc(sizeof(menu_t));
	menu->title = name;
	
	menu->parent = NULL;
	menu->number_of_children = 0;
	menu->func = func;
	return menu;
}


/**
 * @brief Maps parent and child menues togheter.
 *
 * @param parent: parent
 * @param child: child
 * @retval int8_t: success/fail
 */ 
int8_t Menu_allocate_child(menu_t *parent, menu_t *child)
{
	if(parent->number_of_children < 8)
	{
		parent->child[parent->number_of_children++] = child;
		child->parent = parent;
		return 0;
	}
	else
	{
		return -1;
	}
}


/**
 * @brief Initialization function for the menu system.
 * Builds and maps the menu system.
 *
 * @param  none
 * @retval menu_t*: pointer to the first menu
 */ 
menu_t *Menu_init(void) 
{
	//Create and allocate memory to menus
	menu_t* Main_menu		= Menu_create_menu(MAIN_MENU_STRING, NULL);
	menu_t* Start_game		= Menu_create_menu(START_GAME_STRING, NULL);	
	menu_t* difficulties	= Menu_create_menu(SET_DIFFICULTY_STRING, NULL);	
	menu_t* highscore		= Menu_create_menu(HIGH_SCORE_STRING, Menu_wite_high_score);
	menu_t* calibrate		= Menu_create_menu(CALIBRATE_STRING, NULL);
	menu_t* credits			= Menu_create_menu(CREDITS_STRING, Menu_write_credits);
	
	menu_t* easy			= Menu_create_menu(NORMAL_STRING, set_difficulty_func);
	menu_t* hard			= Menu_create_menu(HARD_STRING, set_difficulty_func);	
	menu_t* select_player1	= Menu_create_menu(PLAYER1_STRING, Menu_function_start_game);
	menu_t* select_player2	= Menu_create_menu(PLAYER2_STRING, Menu_function_start_game);
	menu_t* select_player3	= Menu_create_menu(PLAYER3_STRING, Menu_function_start_game);
		
	//Link children and parents	
	Menu_allocate_child(Main_menu, Start_game);
	Menu_allocate_child(Start_game, select_player1);
	Menu_allocate_child(Start_game, select_player2);
	Menu_allocate_child(Start_game, select_player3);
		
	Menu_allocate_child(Main_menu, difficulties);
	Menu_allocate_child(Main_menu, highscore);
	Menu_allocate_child(Main_menu, calibrate);
	Menu_allocate_child(Main_menu, credits);

	Menu_allocate_child(difficulties, easy);
	Menu_allocate_child(difficulties, hard);
	
	//Set current menu to point to main menu
	current_menu = Main_menu;
	current_menu_size = current_menu->number_of_children;
	
	//Write first menu (main menu) to the OLED screen
	Menu_print_menu(current_menu, 1);

	return current_menu;
}


/**
 * @brief Function for traversing the menu system.
 * Uses input from the joystick.
 * @param  none
 * @retval none
 */ 
void Menu_selection(void) 
{
	Direction_t direction;
	direction = Joystick_get_direction();
	
	//Counter for keeping track of where the screen cursor is pointing
	static int menu_ptr = 1;
	
	switch(direction)
	{
		case UP:		//Move cursor up
			if(--menu_ptr < 1) 									//Decrement menu_ptr and ensure roll-over
			{
				menu_ptr = current_menu->number_of_children;
			}
			//Menu_print_menu(current_menu, menu_ptr);			//Output menu, with cursor pointing to menu_ptr
		break;
		
		case DOWN:		//Move cursor down
			if(++menu_ptr > current_menu->number_of_children)	//Increment menu_ptr and ensure roll-over
			{
				menu_ptr = 1;
			}
			else if(menu_ptr > 6)
			{
				menu_ptr = 1;
			}
			//Menu_print_menu(current_menu, menu_ptr);			//Output menu, with cursor pointing to menu_ptr
		break;
		
		case LEFT:		//Move one level up in the system 
			if(current_menu->parent != NULL)					//If current menu have a parent	
			{
				current_menu = current_menu->parent;			//Point to parent
			}
		break;
		
		case RIGHT:		//Enter sub-menu
 			if(current_menu->child[menu_ptr-1]->number_of_children != 0)	//If the cursor is pointing to a child with children
 			{
 				current_menu = current_menu->child[menu_ptr-1];				//Point to child
 			}
		break;
		
		default:		//Do nothing
				//Menu_print_menu(current_menu, menu_ptr);	
		break;
	}
	
	Menu_print_menu(current_menu, menu_ptr); 					//Output menu to screen, with updated cursor
	
	if(Joystick_read_button())									//Check if the joystick button have been pressed
	{
		if(current_menu->child[menu_ptr-1]->func != NULL)		//If the child pointed to have a function attached
		{
			current_menu->child[menu_ptr-1]->func(menu_ptr);	//Excecute function
		}
		else if(current_menu->child[menu_ptr-1]->number_of_children != 0)	//Same as case right above
		{
			current_menu = current_menu->child[menu_ptr-1];
		}
	}
}


/**
 * @brief Function attached to "Start game" menu option
 * Starts a new game if node 2 is ready.
 *
 * @param  choice: chosen player
 * @retval none
 */ 
void Menu_function_start_game(int8_t choice)
{
	current_player = choice;

	OLED_clear();
		
	if(NODE2_READY_FLAG)		//Start game if node 2 is ready
	{		
		//"Starting in"
		Menu_pgm_write_string(MENU_START_STRINGS[0], 2, 10);
		
		//"3..."
		Menu_pgm_write_string(MENU_START_STRINGS[1], 3, 10);
		_delay_ms(1000);
		
		//"2..."
		Menu_pgm_write_string(MENU_START_STRINGS[2], 3, 10);
		_delay_ms(1000);
		
		//"1..."
		Menu_pgm_write_string(MENU_START_STRINGS[3], 3, 10);
		_delay_ms(1000);
		
		//"START!"
		Menu_pgm_write_string(MENU_START_STRINGS[4], 3, 10);
		
		running = 1;		//Set game running flag
		Send_msg(START);	//Send start message
		Timer1_start();		//Start score timer @100ms
		//OLED_clear();
	}
	else							//Write error message if node 2 not ready
	{	
		//"NODE 2 not ready"
		Menu_pgm_write_string(MENU_START_STRINGS[5], 3, 0);

		//"Exiting game"
		Menu_pgm_write_string(MENU_START_STRINGS[6], 3, 0);
		_delay_ms(2500);
	}
}


/**
 * @brief Outputs menu title and childrens title on OLED screen.
 * Retrieves strings from progmem and buffers them in menu_title[],
 * then writes to OLED.
 *
 * @param  menu: pointer print menu
 * @param menu_ptr: position of screen cursor
 * @retval none
 */ 
void Menu_print_menu(menu_t *menu, int8_t menu_ptr) 
{
	uint8_t menu_title[17];	

	OLED_clear();
	//Write title
	Menu_pgm_write_string(menu->title, 0, 0);
	
	//"---------------"
	Menu_pgm_write_string(MENU_GAME_STRINGS[0], 1, 0);
	
	//Output children titles
	for(int i = 0; i < 6; i++)
	{
		if(i >= menu->number_of_children)
		{
			OLED_clear_line(i+2);
		}
		else
		{
			OLED_goto(i + 2, 0);
			strncpy_P(menu_title, menu->child[i]->title, 16);
			if(i == menu_ptr - 1) 
			{
				//Invert text to output screen cursor
				OLED_INV_write_string(menu_title);
			}
			else
			{
				OLED_write_string(menu_title);
			}
		}
	}
}

/**
 * @brief Writes game score to OLED
 * 
 * @param score: value to be presented as score
 * @retval none
 */ 
void Menu_write_score(uint16_t score)
{
	//"Current score"
	Menu_pgm_write_string(MENU_GAME_STRINGS[1], 3, 0);
	OLED_goto(4, 0);
	char num_string[6];
	sprintf(num_string, "%d", score);
		
	OLED_write_string(num_string);
}


/**
 * @brief Writes "game over"-message to OLED
 * 
 * @param score: value to be presented as final score
 * @retval none
 */ 
void Menu_write_game_over(uint16_t score)
{
 	char num_string[6];
	//convert score to string
 	sprintf(num_string, "%d", score);	
 
 	OLED_clear();
	
	//"GAME OVER!"
 	Menu_pgm_write_string(MENU_GAME_STRINGS[2], 1, 0);
	
	//"Your score was:"
	Menu_pgm_write_string(MENU_GAME_STRINGS[3], 2, 0);
 	
 	OLED_goto(3,0);
	//Score
 	OLED_write_string(num_string);
	 	
	 _delay_ms(4000);
	
	//Check if highscore is higher than the previous high score
	Menu_edit_high_score(score, current_player); //Current player
}


/**
 * @brief Writes maker Credits to OLED
 * 
 * @param choice: dummy parameter
 * @retval none
 */ 
void Menu_write_credits(int8_t choice)
{
	OLED_clear();
	for(int i = 0; i < 4; i++)
	{
		Menu_pgm_write_string(MENU_CREDITS_STRING[i], i+1, 0);
	}
	_delay_ms(5000);
}


/**
 * @brief Updates high scores
 * Checks if the input score is higher than the current high score
 * and updates current high score
 *
 * @param new_score: new score
 * @param player: current player
 * @retval none
 */
void Menu_edit_high_score(uint16_t new_score, uint8_t player)
{
	if(new_score > highscores[player-1])
	{
		highscores[player-1] = new_score; 
	}

	Menu_wite_high_score(0);
}


/**
 * @brief Outputs high scores to OLED
 *
 * @param choice: dummy parameter
 * @retval none
 */
void Menu_wite_high_score(int8_t choice)
{	
	OLED_clear();
	
	char s[7];
	
 	//"HIGH SCORES"
	Menu_pgm_write_string(Highscore_title_place, 0, 0);
	
	//Name 1
	Menu_pgm_write_string(Highscore_name1_place, 1, 0);	
	OLED_goto(2,0);
	sprintf(s, "%d", highscores[0]);
	OLED_write_string(s);

	//Name 2
	Menu_pgm_write_string(Highscore_name2_place, 3, 0);	
	
	OLED_goto(4,0);
	sprintf(s, "%d", highscores[1]);
	OLED_write_string(s);	

	//Name 3
	OLED_write_string(s);
	Menu_pgm_write_string(Highscore_name3_place, 5, 0);	
	
	
	OLED_goto(6,0);
	sprintf(s, "%d", highscores[2]);
	OLED_write_string(s);	

 	_delay_ms(4000);
}


/**
 * @brief Updates current player
 *
 * @param choice: new player
 * @retval none
 */
void select_player_func(int8_t choice)
{
	current_player = choice;
}


/**
 * @brief Writes a string from progmem to OLED
 *
 * @param p_s: pointer to string in progmem 
 * @param line: OLED line
 * @param col: OLED column
 * @retval none
 */
void Menu_pgm_write_string(const unsigned char *p_s, uint8_t line, uint8_t col)
{
	char s[16];
	OLED_goto(line, col);
	strncpy_P(s, p_s, 16);
	OLED_write_string(s);		
}


/**
 * @brief Sets game difficulty
 * @note Unimplemented as of 16nov2020
 *
 * @param choice: difficulty
 * @retval none
 */
void set_difficulty_func(int8_t choice)
{
	
	if(choice)
	{
		difficulty_grade = 1;//Hard
	}
	else
	{
		difficulty_grade = 0;//easy
	}
	
}